# TradePulse Web (Merchant App)

A React frontend for the TradePulse group-buying API. This is phase 1: the
merchant-facing side — logging in, browsing buying pools, committing order
volume, and checking wallet balance. An admin dashboard is a separate phase.

## Prerequisites

- Node.js 18 or higher (check with `node -v`)
- The TradePulse backend already running on `http://localhost:8080` (see the
  backend project's own README) with Docker's Postgres/Redis containers up.

## Setup

```bash
npm install
npm run dev
```

Open the URL it prints (usually `http://localhost:5173`).

## Logging in

Use one of the seeded demo merchants (see the backend's `V2__seed_sample_data.sql`):

- `omsai.vasai@tradepulse.io` / `Password123!`
- `manvelpada.mart@tradepulse.io` / `Password123!`

## Configuration

By default the app talks to `http://localhost:8080`. To point it somewhere
else, create a `.env` file (copy `.env.example`) and set `VITE_API_BASE_URL`.

## Project structure

- `src/lib/` — API calls (axios), one file per backend domain (auth, pools, wallet)
- `src/context/AuthContext.jsx` — login state, stored in localStorage
- `src/components/` — shared UI pieces (nav, badges, tier progress bar, money formatting)
- `src/pages/` — one file per screen

## Known limits of this phase

- No product/pool creation UI yet (that's an admin-side feature, phase 2)
- No delivery/invoice tracking screens yet
- No merchant self-registration screen yet (merchants are only seeded via the backend for now)
