import { useEffect, useState } from 'react'
import { AlertCircle, CheckCircle2, PiggyBank } from 'lucide-react'
import Layout from '../components/Layout'
import Money from '../components/Money'
import { useAuth } from '../context/AuthContext'
import { getMerchantBalance, depositFunds } from '../lib/wallet'
import { extractErrorMessage } from '../lib/api'

function WalletSkeleton() {
  return (
    <div className="wallet-grid">
      {[0, 1, 2].map((i) => (
        <div className="card wallet-stat" key={i}>
          <div className="skeleton skeleton-line" style={{ width: '50%' }} />
          <div className="skeleton" style={{ height: '28px', width: '75%' }} />
        </div>
      ))}
    </div>
  )
}

export default function WalletPage() {
  const { user } = useAuth()
  const [overview, setOverview] = useState(null)
  const [loadError, setLoadError] = useState('')

  const [amount, setAmount] = useState('')
  const [depositing, setDepositing] = useState(false)
  const [depositError, setDepositError] = useState('')
  const [depositSuccess, setDepositSuccess] = useState('')

  function loadBalance() {
    getMerchantBalance(user.merchantId)
      .then(setOverview)
      .catch((err) => setLoadError(extractErrorMessage(err, 'Could not load wallet balance.')))
  }

  useEffect(loadBalance, [user.merchantId])

  async function handleDeposit(e) {
    e.preventDefault()
    setDepositError('')
    setDepositSuccess('')
    setDepositing(true)
    try {
      await depositFunds(user.merchantId, Number(amount))
      setDepositSuccess(`Deposit of ${amount} recorded.`)
      setAmount('')
      loadBalance()
    } catch (err) {
      setDepositError(extractErrorMessage(err, 'Could not process this deposit.'))
    } finally {
      setDepositing(false)
    }
  }

  return (
    <Layout>
      <div className="page-head">
        <h1>Wallet</h1>
      </div>

      {loadError && (
        <div className="banner banner--error">
          <AlertCircle size={16} />
          <span>{loadError}</span>
        </div>
      )}

      {!overview && !loadError && <WalletSkeleton />}

      {overview && (
        <div className="wallet-grid">
          <div className="card wallet-stat wallet-stat--available">
            <div className="wallet-stat__label">Available</div>
            <div className="wallet-stat__value">
              <Money value={overview.availableBalance} />
            </div>
          </div>
          <div className="card wallet-stat wallet-stat--escrow">
            <div className="wallet-stat__label">In escrow</div>
            <div className="wallet-stat__value">
              <Money value={overview.escrowHoldBalance} />
            </div>
          </div>
          <div className="card wallet-stat">
            <div className="wallet-stat__label">Total</div>
            <div className="wallet-stat__value">
              <Money value={overview.totalBalance} />
            </div>
          </div>
        </div>
      )}

      <h2 style={{ display: 'flex', alignItems: 'center', gap: '0.5rem' }}>
        <PiggyBank size={19} />
        Add funds
      </h2>
      <form onSubmit={handleDeposit} style={{ maxWidth: 320, marginTop: '0.9rem' }}>
        {depositError && (
          <div className="banner banner--error">
            <AlertCircle size={16} />
            <span>{depositError}</span>
          </div>
        )}
        {depositSuccess && (
          <div className="banner banner--success">
            <CheckCircle2 size={16} />
            <span>{depositSuccess}</span>
          </div>
        )}
        <div className="field">
          <label htmlFor="amount">Amount</label>
          <input
            id="amount"
            type="number"
            min="1"
            step="0.01"
            value={amount}
            onChange={(e) => setAmount(e.target.value)}
            required
          />
        </div>
        <button type="submit" className="btn btn--primary btn--full" disabled={depositing}>
          {depositing ? 'Processing...' : 'Deposit'}
        </button>
      </form>
    </Layout>
  )
}
