import { useEffect, useState } from 'react'
import { AlertCircle, Receipt } from 'lucide-react'
import Layout from '../components/Layout'
import StatusBadge from '../components/StatusBadge'
import Money from '../components/Money'
import { useAuth } from '../context/AuthContext'
import { api, extractErrorMessage } from '../lib/api'

async function getMyInvoices(merchantId) {
  const response = await api.get(`/api/v1/fulfillment/sub-invoices/merchant/${merchantId}`)
  return response.data.data
}

export default function InvoicesPage() {
  const { user } = useAuth()
  const [invoices, setInvoices] = useState(null)
  const [error, setError] = useState('')

  useEffect(() => {
    getMyInvoices(user.merchantId)
      .then(setInvoices)
      .catch((err) => setError(extractErrorMessage(err, 'Could not load your invoices.')))
  }, [user.merchantId])

  return (
    <Layout>
      <div className="page-head">
        <h1>Invoices</h1>
        <span className="page-head__meta">{invoices ? `${invoices.length} total` : ''}</span>
      </div>

      {error && (
        <div className="banner banner--error">
          <AlertCircle size={16} />
          <span>{error}</span>
        </div>
      )}

      {!invoices && !error && <div className="loading-state">Loading invoices...</div>}

      {invoices && invoices.length === 0 && (
        <div className="empty-state">
          <Receipt size={32} style={{ marginBottom: '0.8rem', opacity: 0.5 }} />
          <h3>No invoices yet</h3>
          <p>Invoices appear here once a pool you've committed to has its purchase order issued.</p>
        </div>
      )}

      {invoices && invoices.length > 0 && (
        <div className="ledger-list">
          {invoices.map((inv) => (
            <div className="ledger-row" key={inv.subInvoiceId}>
              <div className="pool-row__top">
                <div>
                  <div className="pool-row__title">{inv.invoiceNumber}</div>
                  <div className="pool-row__sub">
                    {inv.quantity} units &middot; <StatusBadge status={inv.dispatchStatus || inv.status} />
                  </div>
                </div>
                <div className="pool-row__price">
                  <div className="pool-row__price-value">
                    <Money value={inv.totalAmount} />
                  </div>
                  <div className="pool-row__price-unit">total, incl. GST</div>
                </div>
              </div>
            </div>
          ))}
        </div>
      )}
    </Layout>
  )
}
