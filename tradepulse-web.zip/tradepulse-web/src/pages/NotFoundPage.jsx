import { Link } from 'react-router-dom'

export default function NotFoundPage() {
  return (
    <div className="empty-state" style={{ paddingTop: '5rem' }}>
      <h3>Page not found</h3>
      <p style={{ marginBottom: '1.2rem' }}>That page doesn't exist.</p>
      <Link to="/pools" className="btn btn--primary">
        Go to buying pools
      </Link>
    </div>
  )
}
