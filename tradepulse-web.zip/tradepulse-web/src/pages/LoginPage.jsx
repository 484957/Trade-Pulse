import { useState } from 'react'
import { useNavigate } from 'react-router-dom'
import { AlertCircle, Boxes } from 'lucide-react'
import { useAuth } from '../context/AuthContext'
import { extractErrorMessage } from '../lib/api'

export default function LoginPage() {
  const { login } = useAuth()
  const navigate = useNavigate()
  const [username, setUsername] = useState('')
  const [password, setPassword] = useState('')
  const [error, setError] = useState('')
  const [submitting, setSubmitting] = useState(false)

  async function handleSubmit(e) {
    e.preventDefault()
    setError('')
    setSubmitting(true)
    try {
      await login(username, password)
      navigate('/pools')
    } catch (err) {
      setError(extractErrorMessage(err, 'Could not log in. Check your email and password.'))
    } finally {
      setSubmitting(false)
    }
  }

  return (
    <div className="auth-screen">
      <div className="auth-layout">
        <div className="auth-hero">
          <svg className="auth-hero__crates" viewBox="0 0 400 560" fill="none" xmlns="http://www.w3.org/2000/svg" aria-hidden="true">
            <g opacity="0.5">
              <rect x="30" y="380" width="90" height="90" rx="4" stroke="#3a4c74" strokeWidth="1.5" />
              <rect x="128" y="410" width="70" height="60" rx="4" stroke="#3a4c74" strokeWidth="1.5" />
              <rect x="30" y="290" width="70" height="80" rx="4" stroke="#3a4c74" strokeWidth="1.5" />
              <rect x="112" y="300" width="55" height="70" rx="4" stroke="#3a4c74" strokeWidth="1.5" />
              <circle cx="300" cy="120" r="70" stroke="#d9932e" strokeWidth="1.5" opacity="0.35" />
              <circle cx="300" cy="120" r="46" stroke="#d9932e" strokeWidth="1.5" opacity="0.55" />
              <line x1="0" y1="470" x2="400" y2="470" stroke="#3a4c74" strokeWidth="1.5" />
            </g>
          </svg>
          <div className="auth-hero__content">
            <div className="auth-hero__eyebrow">
              <Boxes size={16} style={{ verticalAlign: '-3px', marginRight: '0.4rem' }} />
              Group-buying, unlocked together
            </div>
            <h2>Every unit your neighbours order brings your price down.</h2>
          </div>
          <div className="auth-hero__stats">
            <div>
              <div className="auth-hero__stat-value">3</div>
              <div className="auth-hero__stat-label">pricing tiers per pool</div>
            </div>
            <div>
              <div className="auth-hero__stat-value">6</div>
              <div className="auth-hero__stat-label">cluster zones covered</div>
            </div>
          </div>
        </div>

        <div className="auth-panel">
          <div className="auth-card">
            <div className="auth-card__brand">
              Trade<span>Pulse</span>
            </div>
            <p className="auth-card__tagline">Log in to your merchant account</p>

            {error && (
              <div className="banner banner--error">
                <AlertCircle size={16} />
                <span>{error}</span>
              </div>
            )}

            <form onSubmit={handleSubmit}>
              <div className="field">
                <label htmlFor="username">Email</label>
                <input
                  id="username"
                  type="email"
                  value={username}
                  onChange={(e) => setUsername(e.target.value)}
                  autoComplete="username"
                  required
                />
              </div>
              <div className="field">
                <label htmlFor="password">Password</label>
                <input
                  id="password"
                  type="password"
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  autoComplete="current-password"
                  required
                />
              </div>
              <button type="submit" className="btn btn--primary btn--full" disabled={submitting}>
                {submitting ? 'Logging in...' : 'Log in'}
              </button>
            </form>

            <div className="auth-card__hint">
              Seeded demo account: omsai.vasai@tradepulse.io / Password123!
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}
