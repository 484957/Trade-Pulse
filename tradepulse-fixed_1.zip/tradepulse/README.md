# TradePulse: Enterprise Multi-Tenant Group-Buying Aggregator

TradePulse is an enterprise-grade B2B group-buying platform designed to aggregate procurement demand across localized merchant clusters (such as **Vasai-Virar**, Maharashtra). By pooling individual orders from small kirana stores, supermarkets, and restaurants, the platform unlocks wholesale volumetric price tiers directly from tier-1 FMCG distributors and manufacturers.

---

## 🌟 Core Business Engines

### 1. Dynamic Threshold & Price-Tier Engine
- **Mathematical Slabs:** Real-time marginal unit cost recalculations as merchants contribute order quantities.
- **Squeeze & Rebate Protection:** Merchants authorize escrow holds at the initial tier price; as more volume joins and unlocks cheaper tiers, the variance is automatically returned to the merchant's spendable wallet balance upon delivery settlement.
- **Optimistic Concurrency:** Uses JPA `@Version` on buying pool aggregates to prevent lost updates during concurrent high-volume bidding.

### 2. Automated Escrow & Wallet Double-Entry Ledger
- **ACID & Invariant Guarantees:** Strict double-entry accounting where $\sum \text{Debits} = \sum \text{Credits}$ for every transaction.
- **Chart of Accounts (COA):** Segregates `Merchant Available Wallet (Liability)`, `Merchant Escrow Hold (Liability)`, `Distributor Accounts Payable (Liability)`, and `Platform Revenue (Equity)`.
- **Append-Only Immutability:** Balance updates are derived from immutable journal transactions and ledger postings.

### 3. Split-Delivery & Tax-Compliant Invoicing Engine
- **Master PO to Sub-Invoice Allocation:** Converts single bulk distributor consignments into legally independent B2B tax sub-invoices.
- **Indian GST Compliance:** Reverse tax calculation for intra-state Maharashtra (State Code `27`: equal CGST & SGST) based on statutory HSN codes.
- **Last-Mile Route Clustering:** Partitions deliveries into geographic micro-clusters (e.g., `VASAI_WEST`, `VASAI_EAST`, `VIRAR_EAST`) navigating suburban transit choke points.
- **Electronic Proof of Delivery (e-POD):** 6-digit OTP verification upon physical goods handover, automatically unlocking escrow to distributor payables and platform take-rate revenue.

### 4. Scheduled & Asynchronous Batch Processing
- **Decoupled Architecture:** Spring Batch 5 chunk-oriented nightly reconciliation jobs evaluate expired pools, handle automatic refunds, and emit async notifications.
- **Non-Blocking Notifications:** WhatsApp and SMS notification events run asynchronously without blocking user API request threads.

---

## 🏗️ Technology Stack

| Component | Technology |
| :--- | :--- |
| **Backend Framework** | Spring Boot 3.3.3 (Java 21+) |
| **Security & Auth** | Spring Security 6 + JJWT (Stateless RS256 / HMAC-SHA256) |
| **Persistence & ORM** | Spring Data JPA + Hibernate 6 |
| **Database** | PostgreSQL 15+ (with Row-Level Security & Flyway migrations) |
| **Test Database** | In-memory H2 (PostgreSQL compatibility mode) |
| **Batch Processing** | Spring Batch 5 + Spring Task Scheduling |
| **API Documentation** | OpenAPI 3.0 / Swagger UI (springdoc-openapi) |
| **Containerization** | Docker Compose (PostgreSQL 15 + Redis 7) |

---

## 🚀 Quick Start Guide

### Prerequisites
- **JDK 21 or higher** (e.g., OpenJDK 21 / 26)
- **Docker & Docker Compose** (optional for local PostgreSQL and Redis)
- **Maven** (or your favorite Java IDE like IntelliJ IDEA or VS Code)

### Step 1: Start PostgreSQL & Redis via Docker
```bash
docker-compose up -d
```
*Note: If you run tests using `mvn test` or IntelliJ, the application runs against the embedded H2 test database without requiring external Docker containers.*

### Step 2: Build and Run Application
```bash
# Build project
mvn clean install

# Run Spring Boot application
mvn spring-boot:run
```
The server will start on port `8080`.

### Step 3: Interactive Swagger API Docs
Open your browser and navigate to:
```
http://localhost:8080/swagger-ui.html
```

---

## 📋 Vasai-Virar End-to-End Walkthrough (API Examples)

### 1. Authenticate & Obtain Merchant JWT
```bash
curl -X POST http://localhost:8080/api/v1/auth/login \
  -H "Content-Type: application/json" \
  -d '{
    "username": "omsai.vasai@tradepulse.io",
    "password": "Password123!",
    "tenantId": "a1b2c3d4-0000-0000-0000-000000000001"
  }'
```
*Save the returned `accessToken` and use it in the `Authorization: Bearer <token>` header for subsequent requests.*

---

### 2. View Active Buying Pools & Pricing Slabs
```bash
curl -X GET http://localhost:8080/api/v1/pools \
  -H "Authorization: Bearer <TOKEN>"
```

**Response Preview:**
```json
{
  "success": true,
  "data": [
    {
      "id": "f1b2c3d4-0000-0000-0000-000000000001",
      "title": "Vasai-Virar Edible Oil Bulk Buying Pool #101",
      "status": "OPEN",
      "currentQuantity": 0,
      "targetMoq": 20,
      "maxCapacity": 500,
      "currentUnlockedPrice": 1950.00,
      "tierProgress": {
        "activeTierLevel": null,
        "nextTierLevel": 1,
        "nextUnitPrice": 1950.00,
        "unitsNeededForNextTier": 20
      }
    }
  ]
}
```

---

### 3. Merchant A (Om Sai Kirana, Vasai West) Commits 25 Units
```bash
curl -X POST http://localhost:8080/api/v1/pools/f1b2c3d4-0000-0000-0000-000000000001/commit \
  -H "Authorization: Bearer <TOKEN>" \
  -H "Content-Type: application/json" \
  -d '{
    "merchantId": "b1b2c3d4-0000-0000-0000-000000000001",
    "quantity": 25
  }'
```
- **Outcome:** Pool volume increases to 25 tins (crossing Tier 1 threshold of 20).
- **Price Unlocked:** Tier 1 unlocked at ₹1,950/tin.
- **Escrow Hold:** ₹48,750 locked from Om Sai Kirana's wallet.

---

### 4. Merchant B (Manvelpada Supermarket, Virar East) Commits 80 Units
```bash
curl -X POST http://localhost:8080/api/v1/pools/f1b2c3d4-0000-0000-0000-000000000001/commit \
  -H "Authorization: Bearer <TOKEN>" \
  -H "Content-Type: application/json" \
  -d '{
    "merchantId": "b1b2c3d4-0000-0000-0000-000000000002",
    "quantity": 80
  }'
```
- **Outcome:** Total volume hits 105 tins (crossing Tier 3 threshold of 100).
- **Price Dynamically Squeezed:** Unlocks Tier 3 at ₹1,750/tin!
- **Delta Savings:** ₹200 savings per unit compared to Tier 1.

---

### 5. Generate Master PO & Split Sub-Invoices
```bash
curl -X POST http://localhost:8080/api/v1/fulfillment/pools/f1b2c3d4-0000-0000-0000-000000000001/generate-po \
  -H "Authorization: Bearer <TOKEN>"
```
- Consolidated purchase order generated for 105 tins.
- Generates GST-compliant sub-invoices with individual CGST (2.5%) and SGST (2.5%) amounts.
- Generates delivery manifests grouped by `VASAI_WEST` and `VIRAR_EAST` routes with secret 6-digit delivery OTPs.

---

### 6. Driver Handover: Verify Delivery with OTP (e-POD)
```bash
curl -X POST http://localhost:8080/api/v1/fulfillment/delivery/verify \
  -H "Authorization: Bearer <TOKEN>" \
  -H "Content-Type: application/json" \
  -d '{
    "subInvoiceId": "<SUB_INVOICE_ID>",
    "otp": "<6_DIGIT_OTP>"
  }'
```
- Verifies physical delivery.
- Releases escrow hold to distributor payable.
- Automatically deposits the volume rebate difference back into the merchant's available wallet balance.

---

### 7. Run Nightly Reconciliation Batch Job
```bash
curl -X POST http://localhost:8080/api/v1/batch/trigger-nightly-evaluation \
  -H "Authorization: Bearer <TOKEN>"
```

---

## 🛡️ Database Schema & Isolation

The schema implements multi-tenant isolation via:
- **Tenant Context (`tenant_id`):** Embedded across `merchants`, `products`, `buying_pools`, `accounts`, and `sub_invoices`.
- **PostgreSQL Row-Level Security (RLS):** SQL queries are physically filtered at the database engine level via `SET LOCAL app.current_tenant_id = :tenantId`.
- **Pre-seeded Vasai-Virar Ecosystem:** Included in `V2__seed_sample_data.sql` with real addresses, GSTIN numbers, and FMCG edible oil slabs.

---

## 🧪 Running Automated Tests

Run the full suite of unit and integration tests:
```bash
mvn test
```
**Included Test Cases:**
- `DynamicPoolPricingServiceTest`: Validates dynamic tier transitions, sub-threshold behavior, and next-slab delta savings.
- `DoubleEntryLedgerServiceTest`: Asserts that unbalanced transactions fail with zero-sum violations, and validates escrow hold limits.
- `SplitDeliveryAndInvoicingServiceTest`: Validates Indian GST intra-state (CGST + SGST) vs inter-state (IGST) mathematics.
