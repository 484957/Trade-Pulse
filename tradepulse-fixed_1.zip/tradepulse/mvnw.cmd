@REM ----------------------------------------------------------------------------
@REM Maven Wrapper startup script for Windows (mvnw.cmd)
@REM ----------------------------------------------------------------------------
@IF "%__MVNW_ARG0_NAME__%"=="" (SET "MVN_CMD=mvn.cmd") ELSE (SET "MVN_CMD=%__MVNW_ARG0_NAME__%")

@IF NOT "%JAVA_HOME%"=="" @SET "PATH=%JAVA_HOME%\bin;%PATH%"

@SET MAVEN_PROJECTBASEDIR=%~dp0
@SET MAVEN_OPTS=%MAVEN_OPTS% -Xss2m

@SET WRAPPER_PROPERTIES=%MAVEN_PROJECTBASEDIR%.mvn\wrapper\maven-wrapper.properties
@FOR /F "usebackq tokens=1,* delims==" %%A IN ("%WRAPPER_PROPERTIES%") DO (
    @IF "%%A"=="distributionUrl" SET DISTRIBUTION_URL=%%B
)

@IF NOT EXIST "%USERPROFILE%\.m2\wrapper\dists" MKDIR "%USERPROFILE%\.m2\wrapper\dists"

@echo Downloading Maven if not present...
@IF NOT EXIST "%USERPROFILE%\.m2\wrapper\dists\apache-maven-3.9.6" (
    @powershell -Command "Invoke-WebRequest -Uri '%DISTRIBUTION_URL%' -OutFile '%TEMP%\maven.zip'; Expand-Archive '%TEMP%\maven.zip' -DestinationPath '%USERPROFILE%\.m2\wrapper\dists' -Force"
)

@SET MAVEN_HOME=%USERPROFILE%\.m2\wrapper\dists\apache-maven-3.9.6
@SET PATH=%MAVEN_HOME%\bin;%PATH%

mvn %*
