# Upgrade Plan: tradepulse-core (20260916160015)

- **Generated**: 2026-09-16
- **HEAD Branch**: N/A
- **HEAD Commit ID**: N/A

## Available Tools

**JDKs**
- JDK 21: not available (baseline will be skipped)
- JDK 25: **<TO_BE_INSTALLED>** (required for the target upgrade)
- JDK 26.0.1: `C:\Program Files\Java\jdk-26.0.1\bin` (available, not used as the target)

**Build Tools**
- Maven: **<TO_BE_INSTALLED>** (no Maven installation or wrapper detected; Maven 3.9+ required/recommended)

Version control is unavailable because this workspace is not a Git repository; changes will remain uncommitted.

## Guidelines

> Note: You can add any specific guidelines or constraints for the upgrade process here if needed, bullet points are preferred.

## Options

- Working branch: N/A (version control unavailable)
- Run tests before and after the upgrade: true

## Upgrade Goals

- Java runtime/compiler target: 25 (latest LTS as of 2026-09-16)

## Technology Stack

| Technology/Dependency | Current | Min Compatible Version | Why Incompatible |
| --------------------- | ------- | ---------------------- | ---------------- |
| Java | 21 | 25 | User requested Java runtime upgrade |
| Spring Boot | 3.3.3 | 3.3.3 | Compatible with Java 25 for this target-only change |
| Maven | Not installed | 3.9+ | Required to build and test the project |
| maven-compiler-plugin | Spring Boot parent managed | Java 25-compatible managed version | Must compile against the installed target JDK |
| JUnit/Spring Test | Spring Boot parent managed | Current managed versions | Validate test compatibility on Java 25 |

## Derived Upgrades

- Install JDK 25 because the requested runtime target is Java 25.
- Install Maven 3.9+ because no Maven executable or wrapper is present.
- Keep Spring Boot 3.3.3 and application dependencies unchanged; this request targets the Java runtime only and no incompatibility was identified from the project POM.
- Keep the existing Java 26 installation untouched; it is not the requested LTS target.

## Impact Analysis

### Dependency Changes

| File | Dependency | Current | Action | Target | Reason |
|------|------------|---------|--------|--------|--------|
| `pom.xml` | `java.version` | 21 | upgrade | 25 | Sets Maven compiler and Spring Boot parent Java target |

### Source Code Changes

No source changes identified. The application uses standard Java/Spring APIs and the target-only change does not require namespace or framework migration.

### Configuration Changes

No application configuration changes identified.

### CI/CD Changes

No CI/CD files are present in the workspace. No CI changes are required for the local upgrade.

### Risks & Warnings

- **Java 25 runtime compatibility**: Java 25 may expose compile or runtime issues in older libraries. **Mitigation**: run clean test compilation and the full test suite on JDK 25; fix every failure.
- **Missing baseline JDK**: JDK 21 is unavailable, so the pre-upgrade baseline cannot be reproduced on the original runtime. **Mitigation**: use the existing compiled/test state as context and require clean target-JDK compilation and tests.
- **No version control**: the workspace is not a Git repository. **Mitigation**: record all changes and verification results in progress and summary artifacts.

## Upgrade Steps

- Step 1: Setup Environment
  - **Rationale**: Install JDK 25 and Maven 3.9+ so the target build can execute.
  - **Changes to Make**: Install required tools; leave project files unchanged.
  - **Verification**: List JDKs and Maven; expected JDK 25 and Maven 3.9+ available.

- Step 2: Setup Baseline
  - **Rationale**: Capture pre-upgrade build/test status when the current JDK is available.
  - **Changes to Make**: None.
  - **Verification**: Skipped because JDK 21 is unavailable; document the skip.

- Step 3: Upgrade Java Target
  - **Rationale**: Apply the user-requested Java 25 compiler/runtime target.
  - **Changes to Make**: Update `pom.xml` `java.version` from 21 to 25.
  - **Verification**: `mvn clean test-compile -q` using JDK 25; expected success.

- Step 4: Final Validation
  - **Rationale**: Confirm the complete project builds and all tests pass on Java 25.
  - **Changes to Make**: Fix any Java 25 compatibility failures discovered by validation.
  - **Verification**: `mvn clean test -q` using JDK 25; expected 100% pass rate.

- Step 5: CVE Validation & Fix
  - **Rationale**: Check resolved direct dependency versions for known vulnerabilities after the upgrade.
  - **Changes to Make**: Upgrade only dependencies with reported CVEs, preserving compatibility and security controls.
  - **Verification**: CVE scan, clean test compilation, and re-scan; expected no actionable unresolved CVEs.

- Step 6: Summary and Cleanup
  - **Rationale**: Record outcomes, coverage if available, risks, and final validation evidence.
  - **Changes to Make**: Write `summary.md` and finalize progress records.
  - **Verification**: Confirm all steps are completed and artifacts contain no placeholders.
