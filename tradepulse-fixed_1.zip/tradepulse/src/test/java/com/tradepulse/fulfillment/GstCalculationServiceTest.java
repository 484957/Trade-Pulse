package com.tradepulse.fulfillment;

import com.tradepulse.fulfillment.service.GstCalculationService;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.CsvSource;

import java.math.BigDecimal;

import static org.junit.jupiter.api.Assertions.*;

class GstCalculationServiceTest {

    private final GstCalculationService gstService = new GstCalculationService();

    @Test
    @DisplayName("5% GST intra-state: taxable and CGST/SGST should balance to gross")
    void testGstBalancedToGross() {
        BigDecimal gross = new BigDecimal("21000.00");
        GstCalculationService.TaxBreakdown b = gstService.calculateGst(gross, new BigDecimal("5.00"), "27ABCDE1234F1Z5");

        BigDecimal reconstituted = b.getTaxableAmount().add(b.getCgstAmount()).add(b.getSgstAmount()).add(b.getIgstAmount());
        assertEquals(gross, reconstituted, "Taxable + CGST + SGST must equal gross amount");
    }

    @Test
    @DisplayName("18% GST intra-state: validates CGST == SGST for balanced split")
    void test18PercentIntraStateSplit() {
        BigDecimal gross = new BigDecimal("11800.00"); // 10000 base + 1800 tax at 18%
        GstCalculationService.TaxBreakdown b = gstService.calculateGst(gross, new BigDecimal("18.00"), "27XYZPQ9876R1Z3");

        assertEquals(new BigDecimal("10000.00"), b.getTaxableAmount());
        assertEquals(b.getCgstAmount(), b.getSgstAmount(), "CGST and SGST must be equal for intra-state");
        assertEquals(new BigDecimal("900.00"), b.getCgstAmount());
        assertEquals(new BigDecimal("900.00"), b.getSgstAmount());
        assertEquals(BigDecimal.ZERO, b.getIgstAmount());
    }

    @ParameterizedTest(name = "GST Rate {0}%: Gross {1} -> Taxable {2}, CGST {3}, SGST {4}")
    @CsvSource({
            "5.00,  21000.00, 20000.00,  500.00,  500.00",
            "12.00, 11200.00, 10000.00,  600.00,  600.00",
            "18.00, 11800.00, 10000.00,  900.00,  900.00",
            "28.00, 12800.00, 10000.00, 1400.00, 1400.00"
    })
    @DisplayName("Parameterized intra-state GST scenarios across 5/12/18/28% slabs")
    void testMultipleGstRatesIntraState(
            String gstRate, String gross, String expectedTaxable,
            String expectedCgst, String expectedSgst) {

        GstCalculationService.TaxBreakdown b = gstService.calculateGst(
                new BigDecimal(gross),
                new BigDecimal(gstRate),
                "27TESTGSTIN12345"
        );

        assertEquals(new BigDecimal(expectedTaxable), b.getTaxableAmount());
        assertEquals(new BigDecimal(expectedCgst), b.getCgstAmount());
        assertEquals(new BigDecimal(expectedSgst), b.getSgstAmount());
        assertEquals(BigDecimal.ZERO, b.getIgstAmount());
    }
}
