package com.tradepulse.fulfillment;

import com.tradepulse.fulfillment.service.GstCalculationService;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import java.math.BigDecimal;

import static org.junit.jupiter.api.Assertions.assertEquals;

class SplitDeliveryAndInvoicingServiceTest {

    private final GstCalculationService gstService = new GstCalculationService();

    @Test
    @DisplayName("Should correctly calculate Maharashtra intra-state CGST and SGST for 5% GST rate")
    void testIntraStateGstCalculation() {
        // Gross amount = INR 21,000 (e.g. 12 tins of oil @ 1750 unlocked tier price)
        BigDecimal totalGross = new BigDecimal("21000.00");
        BigDecimal gstRate = new BigDecimal("5.00");
        String maharashtraGstin = "27ABCDE1234F1Z5"; // State code 27

        GstCalculationService.TaxBreakdown breakdown = gstService.calculateGst(totalGross, gstRate, maharashtraGstin);

        // Taxable = 21000 / 1.05 = 20000.00
        // Total Tax = 1000.00 -> CGST = 500.00, SGST = 500.00
        assertEquals(new BigDecimal("20000.00"), breakdown.getTaxableAmount());
        assertEquals(new BigDecimal("500.00"), breakdown.getCgstAmount());
        assertEquals(new BigDecimal("500.00"), breakdown.getSgstAmount());
        assertEquals(BigDecimal.ZERO, breakdown.getIgstAmount());
        assertEquals(new BigDecimal("21000.00"), breakdown.getTotalGrossAmount());
    }

    @Test
    @DisplayName("Should correctly calculate inter-state IGST when merchant GSTIN is outside Maharashtra")
    void testInterStateGstCalculation() {
        BigDecimal totalGross = new BigDecimal("21000.00");
        BigDecimal gstRate = new BigDecimal("5.00");
        String gujaratGstin = "24XYZAB9876C1Z2"; // Gujarat State code 24

        GstCalculationService.TaxBreakdown breakdown = gstService.calculateGst(totalGross, gstRate, gujaratGstin);

        assertEquals(new BigDecimal("20000.00"), breakdown.getTaxableAmount());
        assertEquals(BigDecimal.ZERO, breakdown.getCgstAmount());
        assertEquals(BigDecimal.ZERO, breakdown.getSgstAmount());
        assertEquals(new BigDecimal("1000.00"), breakdown.getIgstAmount());
    }
}
