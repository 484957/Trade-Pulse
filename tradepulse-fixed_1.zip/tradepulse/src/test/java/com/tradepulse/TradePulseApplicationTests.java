package com.tradepulse;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.ActiveProfiles;

@SpringBootTest
@ActiveProfiles("test")
class TradePulseApplicationTests {

    @Test
    void contextLoads() {
        // Verifies that Spring context and all bean wirings load successfully
    }
}
