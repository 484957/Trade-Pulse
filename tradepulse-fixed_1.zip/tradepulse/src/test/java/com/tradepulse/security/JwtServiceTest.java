package com.tradepulse.security.jwt;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.springframework.test.util.ReflectionTestUtils;

import java.util.List;
import java.util.UUID;

import static org.junit.jupiter.api.Assertions.*;

class JwtServiceTest {

    private JwtService jwtService;

    private static final String TEST_SECRET =
            "404E635266556A586E3272357538782F413F4428472B4B6250645367566B5970";

    @BeforeEach
    void setUp() {
        jwtService = new JwtService();
        ReflectionTestUtils.setField(jwtService, "secretKey", TEST_SECRET);
        ReflectionTestUtils.setField(jwtService, "jwtExpirationMs", 86400000L);
    }

    @Test
    @DisplayName("Generated token should be valid and contain the correct username")
    void testTokenGenerationAndValidation() {
        UUID tenantId = UUID.fromString("a1b2c3d4-0000-0000-0000-000000000001");
        UUID userId = UUID.randomUUID();
        String username = "omsai.vasai@tradepulse.io";

        String token = jwtService.generateToken(username, tenantId, userId, List.of("ROLE_MERCHANT"));

        assertNotNull(token);
        assertTrue(jwtService.isTokenValid(token));
        assertEquals(username, jwtService.extractUsername(token));
    }

    @Test
    @DisplayName("Extracted tenant ID must match the original tenant UUID passed during generation")
    void testTenantIdExtraction() {
        UUID tenantId = UUID.fromString("a1b2c3d4-0000-0000-0000-000000000001");
        String token = jwtService.generateToken("test-user", tenantId, UUID.randomUUID(), List.of("ROLE_ADMIN"));

        UUID extractedTenantId = jwtService.extractTenantId(token);
        assertEquals(tenantId, extractedTenantId);
    }

    @Test
    @DisplayName("Tampered token should be detected as invalid")
    void testTamperedTokenIsInvalid() {
        UUID tenantId = UUID.fromString("a1b2c3d4-0000-0000-0000-000000000001");
        String validToken = jwtService.generateToken("merchant", tenantId, UUID.randomUUID(), List.of("ROLE_MERCHANT"));

        // Tamper the payload by modifying a character in the middle
        String tampered = validToken.substring(0, validToken.length() - 5) + "XXXXX";
        assertFalse(jwtService.isTokenValid(tampered));
    }

    @Test
    @DisplayName("Extracted roles list must match the roles embedded at token generation")
    void testRolesExtraction() {
        UUID tenantId = UUID.fromString("a1b2c3d4-0000-0000-0000-000000000001");
        List<String> roles = List.of("ROLE_MERCHANT", "ROLE_ADMIN");
        String token = jwtService.generateToken("superuser", tenantId, UUID.randomUUID(), roles);

        List<String> extracted = jwtService.extractRoles(token);
        assertNotNull(extracted);
        assertTrue(extracted.containsAll(roles));
    }
}
