package com.tradepulse.ledger;

import com.tradepulse.common.exception.BusinessException;
import com.tradepulse.common.exception.InsufficientBalanceException;
import com.tradepulse.ledger.entity.*;
import com.tradepulse.ledger.repository.AccountRepository;
import com.tradepulse.ledger.repository.JournalTransactionRepository;
import com.tradepulse.ledger.repository.LedgerEntryRepository;
import com.tradepulse.ledger.service.DoubleEntryLedgerService;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.math.BigDecimal;
import java.util.List;
import java.util.Optional;
import java.util.UUID;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
class DoubleEntryLedgerServiceTest {

    @Mock
    private AccountRepository accountRepository;

    @Mock
    private JournalTransactionRepository journalTransactionRepository;

    @Mock
    private LedgerEntryRepository ledgerEntryRepository;

    @InjectMocks
    private DoubleEntryLedgerService ledgerService;

    private UUID tenantId;
    private UUID merchantId;
    private Account merchantWallet;
    private Account bankClearing;

    @BeforeEach
    void setUp() {
        tenantId = UUID.randomUUID();
        merchantId = UUID.randomUUID();

        merchantWallet = Account.builder()
                .id(UUID.randomUUID())
                .tenantId(tenantId)
                .ownerId(merchantId)
                .accountNumber("WLT-MERCHANT-01")
                .accountType(AccountType.MERCHANT_AVAILABLE)
                .cachedBalance(new BigDecimal("10000.00"))
                .build();

        bankClearing = Account.builder()
                .id(UUID.randomUUID())
                .tenantId(tenantId)
                .ownerId(UUID.randomUUID())
                .accountNumber("BNK-CLEARING-01")
                .accountType(AccountType.BANK_CLEARING)
                .cachedBalance(BigDecimal.ZERO)
                .build();
    }

    @Test
    @DisplayName("Should reject unbalanced transactions violating the zero-sum invariant")
    void testUnbalancedTransactionThrowsException() {
        List<DoubleEntryLedgerService.EntryPosting> unbalancedPostings = List.of(
                DoubleEntryLedgerService.EntryPosting.builder()
                        .account(bankClearing).entryType(EntryType.DEBIT).amount(new BigDecimal("5000.00")).build(),
                DoubleEntryLedgerService.EntryPosting.builder()
                        .account(merchantWallet).entryType(EntryType.CREDIT).amount(new BigDecimal("4900.00")).build() // Imbalance!
        );

        assertThrows(BusinessException.class, () -> ledgerService.recordBalancedTransaction(
                tenantId, "TXN-TEST-01", "TEST_EVENT", "Test unbalanced", unbalancedPostings
        ));
    }

    @Test
    @DisplayName("Should successfully record balanced transaction and update account balances")
    void testBalancedTransactionSuccess() {
        when(journalTransactionRepository.save(any(JournalTransaction.class)))
                .thenAnswer(inv -> inv.getArgument(0));

        List<DoubleEntryLedgerService.EntryPosting> balancedPostings = List.of(
                DoubleEntryLedgerService.EntryPosting.builder()
                        .account(bankClearing).entryType(EntryType.DEBIT).amount(new BigDecimal("5000.00")).build(),
                DoubleEntryLedgerService.EntryPosting.builder()
                        .account(merchantWallet).entryType(EntryType.CREDIT).amount(new BigDecimal("5000.00")).build()
        );

        JournalTransaction txn = ledgerService.recordBalancedTransaction(
                tenantId, "TXN-TEST-02", "TEST_EVENT", "Test balanced deposit", balancedPostings
        );

        assertNotNull(txn);
        assertEquals(new BigDecimal("15000.00"), merchantWallet.getCachedBalance());
        verify(accountRepository, times(2)).save(any(Account.class));
        verify(ledgerEntryRepository, times(1)).saveAll(anyList());
    }

    @Test
    @DisplayName("Should reject escrow lock when merchant wallet balance is insufficient")
    void testInsufficientBalanceThrowsException() {
        when(accountRepository.findByTenantOwnerTypeWithLock(tenantId, merchantId, AccountType.MERCHANT_AVAILABLE))
                .thenReturn(Optional.of(merchantWallet));

        Account escrowAccount = Account.builder()
                .id(UUID.randomUUID())
                .tenantId(tenantId)
                .ownerId(merchantId)
                .accountNumber("ESC-MERCHANT-01")
                .accountType(AccountType.MERCHANT_ESCROW_HOLD)
                .cachedBalance(BigDecimal.ZERO)
                .build();

        when(accountRepository.findByTenantOwnerTypeWithLock(tenantId, merchantId, AccountType.MERCHANT_ESCROW_HOLD))
                .thenReturn(Optional.of(escrowAccount));

        // Required: 25000.00, Available: 10000.00 -> Should throw InsufficientBalanceException
        assertThrows(InsufficientBalanceException.class, () -> ledgerService.lockEscrowHold(
                tenantId, merchantId, new BigDecimal("25000.00"), "ESC-TEST-01"
        ));
    }
}
