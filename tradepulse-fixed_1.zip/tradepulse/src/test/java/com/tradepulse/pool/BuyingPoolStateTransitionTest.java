package com.tradepulse.pool;

import com.tradepulse.pool.entity.*;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import java.math.BigDecimal;
import java.time.Instant;
import java.util.List;
import java.util.UUID;

import static org.junit.jupiter.api.Assertions.*;

class BuyingPoolStateTransitionTest {

    private BuyingPool pool;

    @BeforeEach
    void setUp() {
        Product product = Product.builder()
                .id(UUID.randomUUID())
                .title("Test Product")
                .sku("TEST-SKU-001")
                .mrp(new BigDecimal("1000.00"))
                .gstRate(new BigDecimal("18.00"))
                .build();

        ProductTier tier1 = ProductTier.builder()
                .product(product).tierLevel(1)
                .minVolumeThreshold(10).unitPrice(new BigDecimal("900.00")).build();
        ProductTier tier2 = ProductTier.builder()
                .product(product).tierLevel(2)
                .minVolumeThreshold(25).unitPrice(new BigDecimal("820.00")).build();

        product.setTiers(List.of(tier1, tier2));

        pool = BuyingPool.builder()
                .id(UUID.randomUUID())
                .tenantId(UUID.randomUUID())
                .product(product)
                .title("Test Pool")
                .status(PoolStatus.OPEN)
                .currentQuantity(0)
                .targetMoq(10)
                .maxCapacity(100)
                .currentUnlockedPrice(new BigDecimal("900.00"))
                .startTime(Instant.now().minusSeconds(3600))
                .cutoffTime(Instant.now().plusSeconds(3600))
                .freezeTime(Instant.now().plusSeconds(1800))
                .build();
    }

    @Test
    @DisplayName("Pool should be open for commitment when status is OPEN and within time window")
    void testPoolIsOpenForCommitment() {
        assertTrue(pool.isOpenForCommitment());
    }

    @Test
    @DisplayName("Pool should not be open for commitment once it is LOCKED")
    void testPoolNotOpenWhenLocked() {
        pool.setStatus(PoolStatus.LOCKED);
        assertFalse(pool.isOpenForCommitment());
    }

    @Test
    @DisplayName("Pool should not be open for commitment when EXPIRED")
    void testPoolNotOpenWhenExpired() {
        pool.setStatus(PoolStatus.EXPIRED);
        assertFalse(pool.isOpenForCommitment());
    }

    @Test
    @DisplayName("Evaluating tier for quantity below minimum should return null")
    void testBelowMinimumTierReturnsNull() {
        ProductTier tier = pool.evaluateTierForQuantity(5);
        assertNull(tier, "No tier should be active below 10 units");
    }

    @Test
    @DisplayName("Evaluating 30 units should return Tier 2 (highest eligible tier)")
    void testTier2SelectedForQuantity30() {
        ProductTier tier = pool.evaluateTierForQuantity(30);
        assertNotNull(tier);
        assertEquals(2, tier.getTierLevel());
        assertEquals(new BigDecimal("820.00"), tier.getUnitPrice());
    }

    @Test
    @DisplayName("Next higher tier from Tier 1 should be Tier 2")
    void testNextHigherTierFromTier1() {
        ProductTier nextTier = pool.getNextHigherTier(15); // currently at Tier1 (10-24)
        assertNotNull(nextTier);
        assertEquals(2, nextTier.getTierLevel());
        assertEquals(25, nextTier.getMinVolumeThreshold());
    }

    @Test
    @DisplayName("No next tier exists when already at maximum tier")
    void testNoNextTierAtMaximumTier() {
        ProductTier nextTier = pool.getNextHigherTier(50); // already at Tier2 (25+)
        assertNull(nextTier, "Should return null when at the maximum discount tier");
    }
}
