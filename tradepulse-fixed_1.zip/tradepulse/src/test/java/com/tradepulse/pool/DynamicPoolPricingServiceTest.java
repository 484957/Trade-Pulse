package com.tradepulse.pool;

import com.tradepulse.pool.entity.BuyingPool;
import com.tradepulse.pool.entity.Product;
import com.tradepulse.pool.entity.ProductTier;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import java.math.BigDecimal;
import java.util.List;
import java.util.UUID;

import static org.junit.jupiter.api.Assertions.*;

class DynamicPoolPricingServiceTest {

    private BuyingPool pool;

    @BeforeEach
    void setUp() {
        Product product = Product.builder()
                .id(UUID.randomUUID())
                .title("Fortune Sunflower Oil 15L Tin")
                .sku("SKU-OIL-15L")
                .mrp(new BigDecimal("2150.00"))
                .gstRate(new BigDecimal("5.00"))
                .build();

        // 4 Volume Tiers
        ProductTier tier1 = ProductTier.builder().product(product).tierLevel(1).minVolumeThreshold(20).unitPrice(new BigDecimal("1950.00")).build();
        ProductTier tier2 = ProductTier.builder().product(product).tierLevel(2).minVolumeThreshold(50).unitPrice(new BigDecimal("1850.00")).build();
        ProductTier tier3 = ProductTier.builder().product(product).tierLevel(3).minVolumeThreshold(100).unitPrice(new BigDecimal("1750.00")).build();
        ProductTier tier4 = ProductTier.builder().product(product).tierLevel(4).minVolumeThreshold(250).unitPrice(new BigDecimal("1650.00")).build();

        product.setTiers(List.of(tier1, tier2, tier3, tier4));

        pool = BuyingPool.builder()
                .product(product)
                .currentQuantity(0)
                .targetMoq(20)
                .maxCapacity(500)
                .currentUnlockedPrice(new BigDecimal("1950.00"))
                .build();
    }

    @Test
    @DisplayName("Should return null tier when committed quantity is below minimum MOQ threshold")
    void testSubThresholdTier() {
        ProductTier tier = pool.evaluateTierForQuantity(15);
        assertNull(tier, "Quantity below 20 should not unlock any tier");
    }

    @Test
    @DisplayName("Should unlock Tier 1 when volume reaches 20 units")
    void testTier1Unlocked() {
        ProductTier tier = pool.evaluateTierForQuantity(25);
        assertNotNull(tier);
        assertEquals(1, tier.getTierLevel());
        assertEquals(new BigDecimal("1950.00"), tier.getUnitPrice());
    }

    @Test
    @DisplayName("Should dynamically unlock Tier 3 (INR 1750) when cumulative volume hits 120 units")
    void testTier3Unlocked() {
        ProductTier tier = pool.evaluateTierForQuantity(120);
        assertNotNull(tier);
        assertEquals(3, tier.getTierLevel());
        assertEquals(new BigDecimal("1750.00"), tier.getUnitPrice());
    }

    @Test
    @DisplayName("Should accurately identify next higher discount slab and delta units needed")
    void testNextTierDeltaCalculation() {
        // Current quantity is 60 (Tier 2 active: INR 1850)
        ProductTier currentTier = pool.evaluateTierForQuantity(60);
        assertEquals(2, currentTier.getTierLevel());

        ProductTier nextTier = pool.getNextHigherTier(60);
        assertNotNull(nextTier);
        assertEquals(3, nextTier.getTierLevel());
        assertEquals(100, nextTier.getMinVolumeThreshold());

        int unitsNeeded = nextTier.getMinVolumeThreshold() - 60;
        assertEquals(40, unitsNeeded, "Should require 40 more units to reach Tier 3");

        BigDecimal potentialSavings = currentTier.getUnitPrice().subtract(nextTier.getUnitPrice());
        assertEquals(new BigDecimal("100.00"), potentialSavings, "Savings per unit from Tier 2 to Tier 3 should be INR 100");
    }
}
