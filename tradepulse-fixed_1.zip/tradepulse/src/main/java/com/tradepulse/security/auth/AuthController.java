package com.tradepulse.security.auth;

import com.tradepulse.common.response.ApiResponse;
import com.tradepulse.merchant.entity.Merchant;
import com.tradepulse.security.jwt.JwtService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.context.annotation.Profile;
import org.springframework.http.ResponseEntity;
import org.springframework.security.authentication.BadCredentialsException;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;
import java.util.UUID;

@RestController
@RequestMapping("/api/v1/auth")
@RequiredArgsConstructor
@Tag(name = "Authentication & JWT", description = "Endpoints for token issuance and merchant authentication")
public class AuthController {

    private final JwtService jwtService;
    private final AuthMerchantLookupService merchantLookupService;
    private final PasswordEncoder passwordEncoder;

    @PostMapping("/login")
    @Operation(summary = "Authenticate a merchant by email + password and return a signed JWT")
    public ResponseEntity<ApiResponse<AuthDto.AuthResponse>> login(@Valid @RequestBody AuthDto.LoginRequest request) {
        // Tenant is derived from the matched merchant record, never trusted
        // from client input - a caller cannot mint a token for an arbitrary
        // tenant by simply naming it in the request body.
        Merchant merchant = merchantLookupService.findByEmailForLogin(request.getUsername())
                .orElseThrow(() -> new BadCredentialsException("Invalid username or password"));

        if (!passwordEncoder.matches(request.getPassword(), merchant.getPasswordHash())) {
            throw new BadCredentialsException("Invalid username or password");
        }

        List<String> roles = merchant.isAdmin()
                ? List.of("ROLE_MERCHANT", "ROLE_ADMIN")
                : List.of("ROLE_MERCHANT");
        String token = jwtService.generateToken(
                merchant.getContactEmail(), merchant.getTenantId(), merchant.getId(), roles);

        AuthDto.AuthResponse response = AuthDto.AuthResponse.builder()
                .accessToken(token)
                .tokenType("Bearer")
                .tenantId(merchant.getTenantId())
                .userId(merchant.getId())
                .username(merchant.getContactEmail())
                .roles(roles)
                .build();

        return ResponseEntity.ok(ApiResponse.ok(response, "Authentication successful"));
    }

    /**
     * Developer-only token minting for local testing. This previously existed
     * with no restriction at all in any environment - any caller could mint a
     * valid token for any tenant/user/role. It is now only registered when
     * the "dev" Spring profile is active, so the bean (and therefore the
     * endpoint) does not exist in a production deployment at all.
     */
    @Profile("dev")
    @RestController
    @RequestMapping("/api/v1/auth")
    @RequiredArgsConstructor
    public static class DevTokenController {

        private final JwtService jwtService;

        @PostMapping("/token")
        @Operation(summary = "[dev profile only] Mint a custom JWT for local testing and tenant switching")
        public ResponseEntity<ApiResponse<AuthDto.AuthResponse>> mintCustomToken(
                @RequestBody AuthDto.TokenGenerationRequest request) {
            UUID tenantId = request.getTenantId();
            if (tenantId == null) {
                throw new IllegalArgumentException("tenantId is required");
            }
            UUID userId = request.getUserId() != null ? request.getUserId() : UUID.randomUUID();
            List<String> roles = request.getRoles() != null && !request.getRoles().isEmpty()
                    ? request.getRoles()
                    : List.of("ROLE_MERCHANT");

            String token = jwtService.generateToken(request.getUsername(), tenantId, userId, roles);

            AuthDto.AuthResponse response = AuthDto.AuthResponse.builder()
                    .accessToken(token)
                    .tokenType("Bearer")
                    .tenantId(tenantId)
                    .userId(userId)
                    .username(request.getUsername())
                    .roles(roles)
                    .build();

            return ResponseEntity.ok(ApiResponse.ok(response, "Token minted successfully (dev profile only)"));
        }
    }
}
