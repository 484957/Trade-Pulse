package com.tradepulse.security.auth;

import java.util.UUID;

/**
 * The merchant id of whoever is making the current request, resolved from
 * their JWT. Used for "is this actually yours" ownership checks - e.g. a
 * merchant should be able to see their own wallet balance and invoices, but
 * not another merchant's, even within the same tenant. Admins bypass this
 * (checked separately via role, not here).
 */
public final class CurrentUserContext {

    private static final ThreadLocal<UUID> CURRENT_USER_ID = new ThreadLocal<>();

    private CurrentUserContext() {
    }

    public static void setUserId(UUID userId) {
        CURRENT_USER_ID.set(userId);
    }

    public static UUID getUserId() {
        return CURRENT_USER_ID.get();
    }

    public static void clear() {
        CURRENT_USER_ID.remove();
    }
}
