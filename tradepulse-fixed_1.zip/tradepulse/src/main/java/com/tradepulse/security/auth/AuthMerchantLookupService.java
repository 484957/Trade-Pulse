package com.tradepulse.security.auth;

import com.tradepulse.merchant.entity.Merchant;
import com.tradepulse.merchant.repository.MerchantRepository;
import jakarta.persistence.EntityManager;
import jakarta.persistence.PersistenceContext;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.Optional;

/**
 * Login has to find a merchant by email before any tenant is known - that
 * lookup is what determines which tenant the caller belongs to. Every other
 * query in the app is scoped by an already-known tenant and relies on the
 * Postgres RLS policy from V3 to enforce that; this one legitimately can't
 * be, so it explicitly (and narrowly) tells that policy to allow it through.
 *
 * The bypass flag is set with SET LOCAL semantics (set_config(..., true)),
 * so it only applies for the duration of this one @Transactional method and
 * is gone the moment it returns - it can never leak onto a later, unrelated
 * query that reuses the same pooled connection.
 */
@Service
@RequiredArgsConstructor
public class AuthMerchantLookupService {

    @PersistenceContext
    private EntityManager entityManager;

    private final MerchantRepository merchantRepository;

    @Transactional
    public Optional<Merchant> findByEmailForLogin(String email) {
        entityManager.createNativeQuery("SELECT set_config('app.bypass_tenant_check', 'true', true)")
                .getSingleResult();
        return merchantRepository.findByContactEmailIgnoreCase(email);
    }
}
