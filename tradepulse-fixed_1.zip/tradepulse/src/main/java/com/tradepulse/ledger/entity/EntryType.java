package com.tradepulse.ledger.entity;

public enum EntryType {
    DEBIT,
    CREDIT
}
