package com.tradepulse.ledger.service;

import com.tradepulse.common.exception.BusinessException;
import com.tradepulse.common.exception.InsufficientBalanceException;
import com.tradepulse.ledger.entity.*;
import com.tradepulse.ledger.repository.AccountRepository;
import com.tradepulse.ledger.repository.JournalTransactionRepository;
import com.tradepulse.ledger.repository.LedgerEntryRepository;
import lombok.Builder;
import lombok.Data;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Isolation;
import org.springframework.transaction.annotation.Transactional;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

@Service
@RequiredArgsConstructor
@Slf4j
public class DoubleEntryLedgerService {

    private final AccountRepository accountRepository;
    private final JournalTransactionRepository journalTransactionRepository;
    private final LedgerEntryRepository ledgerEntryRepository;

    @Data
    @Builder
    public static class EntryPosting {
        private Account account;
        private EntryType entryType;
        private BigDecimal amount;
    }

    @Transactional(isolation = Isolation.REPEATABLE_READ)
    public JournalTransaction recordBalancedTransaction(
            UUID tenantId,
            String transactionRef,
            String eventType,
            String description,
            List<EntryPosting> postings) {

        if (postings == null || postings.size() < 2) {
            throw new BusinessException("A double-entry transaction must contain at least 2 postings");
        }

        BigDecimal totalDebits = BigDecimal.ZERO;
        BigDecimal totalCredits = BigDecimal.ZERO;

        for (EntryPosting posting : postings) {
            if (posting.getAmount().compareTo(BigDecimal.ZERO) <= 0) {
                throw new BusinessException("Posting amount must be strictly positive: " + posting.getAmount());
            }
            if (posting.getEntryType() == EntryType.DEBIT) {
                totalDebits = totalDebits.add(posting.getAmount());
            } else {
                totalCredits = totalCredits.add(posting.getAmount());
            }
        }

        if (totalDebits.compareTo(totalCredits) != 0) {
            throw new BusinessException(String.format(
                    "Ledger Invariant Violation: Debits (%s) do not balance with Credits (%s). Ref: %s",
                    totalDebits, totalCredits, transactionRef));
        }

        JournalTransaction transaction = JournalTransaction.builder()
                .tenantId(tenantId)
                .transactionRef(transactionRef)
                .eventType(eventType)
                .description(description)
                .build();

        JournalTransaction savedTransaction = journalTransactionRepository.save(transaction);

        List<LedgerEntry> entries = new ArrayList<>();
        for (EntryPosting posting : postings) {
            Account account = posting.getAccount();

            // Apply balance update depending on account nature
            // For Liability/Equity accounts (Merchants, Payables, Revenue): Credit increases, Debit decreases
            // For Asset accounts (Bank): Debit increases, Credit decreases
            boolean isAsset = account.getAccountType() == AccountType.BANK_CLEARING;
            BigDecimal delta;
            if (isAsset) {
                delta = posting.getEntryType() == EntryType.DEBIT ? posting.getAmount() : posting.getAmount().negate();
            } else {
                delta = posting.getEntryType() == EntryType.CREDIT ? posting.getAmount() : posting.getAmount().negate();
            }

            BigDecimal newBalance = account.getCachedBalance().add(delta);
            account.setCachedBalance(newBalance);
            accountRepository.save(account);

            LedgerEntry entry = LedgerEntry.builder()
                    .transaction(savedTransaction)
                    .account(account)
                    .entryType(posting.getEntryType())
                    .amount(posting.getAmount())
                    .build();

            entries.add(entry);
        }

        ledgerEntryRepository.saveAll(entries);
        return savedTransaction;
    }

    @Transactional(isolation = Isolation.REPEATABLE_READ)
    public JournalTransaction depositFunds(UUID tenantId, UUID merchantId, BigDecimal amount, String ref) {
        Account merchantWallet = getOrCreateAccount(tenantId, merchantId, AccountType.MERCHANT_AVAILABLE);
        Account bankClearing = getOrCreateSystemAccount(tenantId, AccountType.BANK_CLEARING);

        List<EntryPosting> postings = List.of(
                EntryPosting.builder().account(bankClearing).entryType(EntryType.DEBIT).amount(amount).build(),
                EntryPosting.builder().account(merchantWallet).entryType(EntryType.CREDIT).amount(amount).build()
        );

        return recordBalancedTransaction(tenantId, ref, "WALLET_DEPOSIT", "Merchant deposit via bank/UPI", postings);
    }

    @Transactional(isolation = Isolation.REPEATABLE_READ)
    public JournalTransaction lockEscrowHold(UUID tenantId, UUID merchantId, BigDecimal amount, String ref) {
        Account merchantWallet = getOrCreateAccount(tenantId, merchantId, AccountType.MERCHANT_AVAILABLE);
        Account escrowHold = getOrCreateAccount(tenantId, merchantId, AccountType.MERCHANT_ESCROW_HOLD);

        if (merchantWallet.getCachedBalance().compareTo(amount) < 0) {
            throw new InsufficientBalanceException(
                    merchantWallet.getAccountNumber(),
                    merchantWallet.getCachedBalance(),
                    amount);
        }

        List<EntryPosting> postings = List.of(
                EntryPosting.builder().account(merchantWallet).entryType(EntryType.DEBIT).amount(amount).build(),
                EntryPosting.builder().account(escrowHold).entryType(EntryType.CREDIT).amount(amount).build()
        );

        return recordBalancedTransaction(tenantId, ref, "ESCROW_HOLD_LOCK", "Funds locked for buying pool commitment", postings);
    }

    @Transactional(isolation = Isolation.REPEATABLE_READ)
    public JournalTransaction releaseEscrowHold(UUID tenantId, UUID merchantId, BigDecimal amount, String ref) {
        Account merchantWallet = getOrCreateAccount(tenantId, merchantId, AccountType.MERCHANT_AVAILABLE);
        Account escrowHold = getOrCreateAccount(tenantId, merchantId, AccountType.MERCHANT_ESCROW_HOLD);

        List<EntryPosting> postings = List.of(
                EntryPosting.builder().account(escrowHold).entryType(EntryType.DEBIT).amount(amount).build(),
                EntryPosting.builder().account(merchantWallet).entryType(EntryType.CREDIT).amount(amount).build()
        );

        return recordBalancedTransaction(tenantId, ref, "ESCROW_HOLD_RELEASE", "Unspent escrow hold refunded to available balance", postings);
    }

    @Transactional(isolation = Isolation.REPEATABLE_READ)
    public JournalTransaction settlePoolFulfillment(
            UUID tenantId,
            UUID merchantId,
            UUID distributorId,
            BigDecimal holdAmount,
            BigDecimal finalDueAmount,
            BigDecimal platformFee,
            String ref) {

        Account escrowHold = getOrCreateAccount(tenantId, merchantId, AccountType.MERCHANT_ESCROW_HOLD);
        Account merchantWallet = getOrCreateAccount(tenantId, merchantId, AccountType.MERCHANT_AVAILABLE);
        Account distributorPayable = getOrCreateAccount(tenantId, distributorId, AccountType.DISTRIBUTOR_PAYABLE);
        Account platformRevenue = getOrCreateSystemAccount(tenantId, AccountType.PLATFORM_REVENUE);

        BigDecimal totalCost = finalDueAmount.add(platformFee);
        BigDecimal rebateAmount = holdAmount.subtract(totalCost);

        List<EntryPosting> postings = new ArrayList<>();
        // 1. Release entire hold from escrow
        postings.add(EntryPosting.builder().account(escrowHold).entryType(EntryType.DEBIT).amount(holdAmount).build());

        // 2. Credit distributor payable
        postings.add(EntryPosting.builder().account(distributorPayable).entryType(EntryType.CREDIT).amount(finalDueAmount).build());

        // 3. Credit platform revenue
        if (platformFee.compareTo(BigDecimal.ZERO) > 0) {
            postings.add(EntryPosting.builder().account(platformRevenue).entryType(EntryType.CREDIT).amount(platformFee).build());
        }

        // 4. Credit rebate to merchant wallet if cheaper tier was reached
        if (rebateAmount.compareTo(BigDecimal.ZERO) > 0) {
            postings.add(EntryPosting.builder().account(merchantWallet).entryType(EntryType.CREDIT).amount(rebateAmount).build());
        }

        return recordBalancedTransaction(
                tenantId,
                ref,
                "POOL_FULFILLMENT_SETTLEMENT",
                "Settled pool order: distributor payable, platform fee, and rebate return",
                postings
        );
    }

    public Account getOrCreateAccount(UUID tenantId, UUID ownerId, AccountType type) {
        return accountRepository.findByTenantOwnerTypeWithLock(tenantId, ownerId, type)
                .orElseGet(() -> {
                    String prefix = switch (type) {
                        case MERCHANT_AVAILABLE -> "WLT";
                        case MERCHANT_ESCROW_HOLD -> "ESC";
                        case DISTRIBUTOR_PAYABLE -> "DAP";
                        case PLATFORM_REVENUE -> "REV";
                        case BANK_CLEARING -> "BNK";
                    };
                    Account newAcc = Account.builder()
                            .tenantId(tenantId)
                            .ownerId(ownerId)
                            .accountNumber(prefix + "-" + ownerId.toString().substring(0, 8).toUpperCase())
                            .accountType(type)
                            .cachedBalance(BigDecimal.ZERO)
                            .build();
                    return accountRepository.save(newAcc);
                });
    }

    public Account getOrCreateSystemAccount(UUID tenantId, AccountType type) {
        UUID systemOwnerId = UUID.fromString("00000000-0000-0000-0000-000000000001");
        return getOrCreateAccount(tenantId, systemOwnerId, type);
    }
}
