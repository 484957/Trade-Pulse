package com.tradepulse.ledger.controller;

import com.tradepulse.common.response.ApiResponse;
import com.tradepulse.ledger.dto.LedgerDto;
import com.tradepulse.ledger.entity.Account;
import com.tradepulse.ledger.entity.AccountType;
import com.tradepulse.ledger.entity.JournalTransaction;
import com.tradepulse.ledger.repository.AccountRepository;
import com.tradepulse.ledger.repository.JournalTransactionRepository;
import com.tradepulse.ledger.service.DoubleEntryLedgerService;
import com.tradepulse.common.exception.ResourceNotFoundException;
import com.tradepulse.merchant.repository.MerchantRepository;
import com.tradepulse.security.auth.AuthorizationUtils;
import com.tradepulse.security.auth.CurrentUserContext;
import com.tradepulse.tenant.context.TenantContext;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.AccessDeniedException;
import org.springframework.web.bind.annotation.*;

import java.math.BigDecimal;
import java.util.List;
import java.util.UUID;
import java.util.stream.Collectors;

@RestController
@RequestMapping("/api/v1/ledger")
@RequiredArgsConstructor
@Tag(name = "Escrow & Wallet Ledger", description = "ACID Double-Entry Ledger and Escrow operations")
public class WalletLedgerController {

    private final DoubleEntryLedgerService ledgerService;
    private final AccountRepository accountRepository;
    private final JournalTransactionRepository journalRepository;
    private final MerchantRepository merchantRepository;

    /**
     * Wallet accounts are keyed by (tenantId, merchantId), but merchantId
     * alone is caller-supplied. This enforces two things: the merchant must
     * actually belong to the caller's tenant, AND the caller must either be
     * that merchant themselves or an admin - a regular merchant should never
     * be able to view or fund another merchant's wallet just by knowing
     * their id.
     */
    private void requireSelfOrAdminForMerchant(UUID tenantId, UUID merchantId) {
        merchantRepository.findByIdAndTenantId(merchantId, tenantId)
                .orElseThrow(() -> new ResourceNotFoundException("Merchant", merchantId));

        boolean isSelf = merchantId.equals(CurrentUserContext.getUserId());
        if (!isSelf && !AuthorizationUtils.currentUserIsAdmin()) {
            throw new AccessDeniedException("You can only access your own wallet.");
        }
    }

    @PostMapping("/deposit")
    @Operation(summary = "Deposit funds into merchant wallet (generates balanced double-entry journal)")
    public ResponseEntity<ApiResponse<LedgerDto.TransactionHistoryResponse>> depositFunds(
            @Valid @RequestBody LedgerDto.DepositRequest request) {

        UUID tenantId = TenantContext.requireTenantId();
        requireSelfOrAdminForMerchant(tenantId, request.getMerchantId());

        String ref = request.getPaymentReference() != null
                ? request.getPaymentReference()
                : "DEP-" + UUID.randomUUID().toString().substring(0, 8).toUpperCase();

        JournalTransaction txn = ledgerService.depositFunds(tenantId, request.getMerchantId(), request.getAmount(), ref);

        return ResponseEntity.ok(ApiResponse.ok(mapToResponse(txn), "Deposit completed successfully"));
    }

    @GetMapping("/merchants/{merchantId}/balance")
    @Operation(summary = "Get wallet overview (Available balance + Escrow hold balance)")
    public ResponseEntity<ApiResponse<LedgerDto.MerchantWalletOverview>> getMerchantBalance(
            @PathVariable UUID merchantId) {

        UUID tenantId = TenantContext.requireTenantId();
        requireSelfOrAdminForMerchant(tenantId, merchantId);

        Account availableAcc = ledgerService.getOrCreateAccount(tenantId, merchantId, AccountType.MERCHANT_AVAILABLE);
        Account escrowAcc = ledgerService.getOrCreateAccount(tenantId, merchantId, AccountType.MERCHANT_ESCROW_HOLD);

        BigDecimal available = availableAcc.getCachedBalance();
        BigDecimal escrow = escrowAcc.getCachedBalance();

        LedgerDto.MerchantWalletOverview overview = LedgerDto.MerchantWalletOverview.builder()
                .merchantId(merchantId)
                .availableBalance(available)
                .escrowHoldBalance(escrow)
                .totalBalance(available.add(escrow))
                .currency("INR")
                .build();

        return ResponseEntity.ok(ApiResponse.ok(overview));
    }

    @GetMapping("/transactions")
    @Operation(summary = "Get journal transaction audit trail (your own activity, or the whole tenant's if you're an admin)")
    public ResponseEntity<ApiResponse<List<LedgerDto.TransactionHistoryResponse>>> getTransactions() {
        UUID tenantId = TenantContext.requireTenantId();

        List<JournalTransaction> txns = journalRepository.findAllByTenantIdOrderByPostedAtDesc(tenantId);

        if (!AuthorizationUtils.currentUserIsAdmin()) {
            UUID currentUserId = CurrentUserContext.getUserId();
            txns = txns.stream()
                    .filter(txn -> txn.getEntries().stream()
                            .anyMatch(e -> e.getAccount().getOwnerId().equals(currentUserId)))
                    .collect(Collectors.toList());
        }

        List<LedgerDto.TransactionHistoryResponse> response = txns.stream()
                .map(this::mapToResponse)
                .collect(Collectors.toList());

        return ResponseEntity.ok(ApiResponse.ok(response));
    }

    private LedgerDto.TransactionHistoryResponse mapToResponse(JournalTransaction txn) {
        return LedgerDto.TransactionHistoryResponse.builder()
                .transactionId(txn.getId())
                .transactionRef(txn.getTransactionRef())
                .eventType(txn.getEventType())
                .description(txn.getDescription())
                .postedAt(txn.getPostedAt())
                .entries(txn.getEntries().stream()
                        .map(e -> LedgerDto.EntryResponse.builder()
                                .accountNumber(e.getAccount().getAccountNumber())
                                .accountType(e.getAccount().getAccountType())
                                .entryType(e.getEntryType())
                                .amount(e.getAmount())
                                .build())
                        .collect(Collectors.toList()))
                .build();
    }
}
