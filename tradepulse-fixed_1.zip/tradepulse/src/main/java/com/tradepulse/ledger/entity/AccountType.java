package com.tradepulse.ledger.entity;

public enum AccountType {
    MERCHANT_AVAILABLE,     // Merchant spendable wallet balance
    MERCHANT_ESCROW_HOLD,   // Funds locked in active pools
    DISTRIBUTOR_PAYABLE,    // Payable owed to distributors on fulfillment
    PLATFORM_REVENUE,       // Commission / take-rate earned by TradePulse
    BANK_CLEARING           // Inbound payment gateway clearing
}
