package com.tradepulse.ledger.dto;

import com.tradepulse.ledger.entity.AccountType;
import com.tradepulse.ledger.entity.EntryType;
import jakarta.validation.constraints.DecimalMin;
import jakarta.validation.constraints.NotNull;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.math.BigDecimal;
import java.time.Instant;
import java.util.List;
import java.util.UUID;

public class LedgerDto {

    @Data
    @Builder
    @NoArgsConstructor
    @AllArgsConstructor
    public static class DepositRequest {
        @NotNull(message = "Merchant ID is required")
        private UUID merchantId;

        @NotNull(message = "Deposit amount is required")
        @DecimalMin(value = "1.00", message = "Minimum deposit is INR 1.00")
        private BigDecimal amount;

        private String paymentReference;
    }

    @Data
    @Builder
    @NoArgsConstructor
    @AllArgsConstructor
    public static class AccountBalanceResponse {
        private UUID accountId;
        private UUID ownerId;
        private String accountNumber;
        private AccountType accountType;
        private BigDecimal balance;
        private String currency;
    }

    @Data
    @Builder
    @NoArgsConstructor
    @AllArgsConstructor
    public static class MerchantWalletOverview {
        private UUID merchantId;
        private BigDecimal availableBalance;
        private BigDecimal escrowHoldBalance;
        private BigDecimal totalBalance;
        private String currency;
    }

    @Data
    @Builder
    @NoArgsConstructor
    @AllArgsConstructor
    public static class TransactionHistoryResponse {
        private UUID transactionId;
        private String transactionRef;
        private String eventType;
        private String description;
        private Instant postedAt;
        private List<EntryResponse> entries;
    }

    @Data
    @Builder
    @NoArgsConstructor
    @AllArgsConstructor
    public static class EntryResponse {
        private String accountNumber;
        private AccountType accountType;
        private EntryType entryType;
        private BigDecimal amount;
    }
}
