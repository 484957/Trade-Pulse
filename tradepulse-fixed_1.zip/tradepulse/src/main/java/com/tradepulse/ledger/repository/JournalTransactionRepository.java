package com.tradepulse.ledger.repository;

import com.tradepulse.ledger.entity.JournalTransaction;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;
import java.util.UUID;

@Repository
public interface JournalTransactionRepository extends JpaRepository<JournalTransaction, UUID> {
    Optional<JournalTransaction> findByTransactionRef(String transactionRef);
    List<JournalTransaction> findAllByTenantIdOrderByPostedAtDesc(UUID tenantId);
}
