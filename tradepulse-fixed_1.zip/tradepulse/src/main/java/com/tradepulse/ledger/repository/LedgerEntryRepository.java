package com.tradepulse.ledger.repository;

import com.tradepulse.ledger.entity.LedgerEntry;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.UUID;

@Repository
public interface LedgerEntryRepository extends JpaRepository<LedgerEntry, UUID> {
    List<LedgerEntry> findAllByAccountIdOrderByCreatedAtDesc(UUID accountId);
    List<LedgerEntry> findAllByTransactionId(UUID transactionId);
}
