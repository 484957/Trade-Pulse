package com.tradepulse.ledger.repository;

import com.tradepulse.ledger.entity.Account;
import com.tradepulse.ledger.entity.AccountType;
import jakarta.persistence.LockModeType;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Lock;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;
import java.util.UUID;

@Repository
public interface AccountRepository extends JpaRepository<Account, UUID> {

    Optional<Account> findByAccountNumber(String accountNumber);

    Optional<Account> findByTenantIdAndOwnerIdAndAccountType(UUID tenantId, UUID ownerId, AccountType accountType);

    @Lock(LockModeType.PESSIMISTIC_WRITE)
    @Query("SELECT a FROM Account a WHERE a.id = :id")
    Optional<Account> findByIdWithLock(@Param("id") UUID id);

    @Lock(LockModeType.PESSIMISTIC_WRITE)
    @Query("SELECT a FROM Account a WHERE a.tenantId = :tenantId AND a.ownerId = :ownerId AND a.accountType = :accountType")
    Optional<Account> findByTenantOwnerTypeWithLock(
            @Param("tenantId") UUID tenantId,
            @Param("ownerId") UUID ownerId,
            @Param("accountType") AccountType accountType);

    List<Account> findAllByTenantIdAndOwnerId(UUID tenantId, UUID ownerId);
}
