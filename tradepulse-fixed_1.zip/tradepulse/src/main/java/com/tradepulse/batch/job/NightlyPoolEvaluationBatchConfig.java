package com.tradepulse.batch.job;

import com.tradepulse.batch.service.AsyncNotificationService;
import com.tradepulse.fulfillment.service.SplitDeliveryAndInvoicingService;
import com.tradepulse.ledger.service.DoubleEntryLedgerService;
import com.tradepulse.pool.entity.CommitmentStatus;
import com.tradepulse.pool.entity.PoolCommitment;
import com.tradepulse.pool.entity.PoolStatus;
import com.tradepulse.pool.repository.BuyingPoolRepository;
import com.tradepulse.pool.repository.PoolCommitmentRepository;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.batch.core.Job;
import org.springframework.batch.core.Step;
import org.springframework.batch.core.job.builder.JobBuilder;
import org.springframework.batch.core.launch.support.RunIdIncrementer;
import org.springframework.batch.core.repository.JobRepository;
import org.springframework.batch.core.step.builder.StepBuilder;
import org.springframework.batch.core.step.tasklet.Tasklet;
import org.springframework.batch.repeat.RepeatStatus;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.transaction.PlatformTransactionManager;

import java.math.BigDecimal;
import java.time.Instant;
import java.util.List;

@Configuration
@RequiredArgsConstructor
@Slf4j
public class NightlyPoolEvaluationBatchConfig {

    private final JobRepository jobRepository;
    private final PlatformTransactionManager transactionManager;
    private final BuyingPoolRepository poolRepository;
    private final PoolCommitmentRepository commitmentRepository;
    private final DoubleEntryLedgerService ledgerService;
    private final SplitDeliveryAndInvoicingService splitDeliveryService;
    private final AsyncNotificationService notificationService;

    @Bean
    public Job nightlyPoolEvaluationJob(Step evaluateAndReconcilePoolsStep) {
        return new JobBuilder("nightlyPoolEvaluationJob", jobRepository)
                .incrementer(new RunIdIncrementer())
                .start(evaluateAndReconcilePoolsStep)
                .build();
    }

    @Bean
    public Step evaluateAndReconcilePoolsStep() {
        return new StepBuilder("evaluateAndReconcilePoolsStep", jobRepository)
                .tasklet(poolEvaluationTasklet(), transactionManager)
                .build();
    }

    @Bean
    public Tasklet poolEvaluationTasklet() {
        return (contribution, chunkContext) -> {
            Instant now = Instant.now();
            log.info("[BATCH-JOB] Starting Nightly Pool Evaluation at {}", now);

            var expiredPools = poolRepository.findExpiredOpenPools(now);
            log.info("[BATCH-JOB] Found {} pools reaching cutoff time for reconciliation", expiredPools.size());

            for (var pool : expiredPools) {
                if (pool.getCurrentQuantity() >= pool.getTargetMoq()) {
                    // Scenario 1: Pool succeeded -> Lock and generate Master PO + Sub-invoices
                    log.info("[BATCH-JOB] Pool {} succeeded (Qty: {} >= MOQ: {}). Generating Master PO...",
                            pool.getId(), pool.getCurrentQuantity(), pool.getTargetMoq());
                    try {
                        splitDeliveryService.generateMasterPoAndSubInvoices(pool.getTenantId(), pool.getId());
                    } catch (Exception e) {
                        log.error("[BATCH-JOB] Failed to generate Master PO for pool {}", pool.getId(), e);
                    }
                } else {
                    // Scenario 2: Pool failed MOQ -> Expire pool and refund all merchant escrow holds
                    log.warn("[BATCH-JOB] Pool {} failed MOQ (Qty: {} < MOQ: {}). Refunding escrow holds...",
                            pool.getId(), pool.getCurrentQuantity(), pool.getTargetMoq());

                    pool.setStatus(PoolStatus.EXPIRED);
                    poolRepository.save(pool);

                    List<PoolCommitment> commitments = commitmentRepository.findAllByPoolId(pool.getId());
                    for (PoolCommitment commitment : commitments) {
                        if (commitment.getStatus() == CommitmentStatus.CONFIRMED
                                || commitment.getStatus() == CommitmentStatus.HOLD_PENDING) {

                            BigDecimal refundAmount = commitment.getLockedUnitPrice()
                                    .multiply(BigDecimal.valueOf(commitment.getQuantity()));

                            String refundRef = "REFUND-EXP-" + pool.getId().toString().substring(0, 8) + "-" + commitment.getId().toString().substring(0, 6);

                            // Refund ledger escrow back into merchant available wallet
                            ledgerService.releaseEscrowHold(
                                    pool.getTenantId(),
                                    commitment.getMerchantId(),
                                    refundAmount,
                                    refundRef
                            );

                            commitment.setStatus(CommitmentStatus.REFUNDED);
                            commitmentRepository.save(commitment);

                            // Trigger async notification outside batch thread
                            notificationService.notifyPoolExpiredAsync(
                                    commitment.getMerchantId(),
                                    pool.getTitle(),
                                    refundAmount
                            );
                        }
                    }
                }
            }

            log.info("[BATCH-JOB] Nightly Pool Evaluation completed successfully.");
            return RepeatStatus.FINISHED;
        };
    }
}
