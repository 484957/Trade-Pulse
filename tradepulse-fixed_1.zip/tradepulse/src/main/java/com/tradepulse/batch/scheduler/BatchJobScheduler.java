package com.tradepulse.batch.scheduler;

import com.tradepulse.common.response.ApiResponse;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.batch.core.Job;
import org.springframework.batch.core.JobParameters;
import org.springframework.batch.core.JobParametersBuilder;
import org.springframework.batch.core.launch.JobLauncher;
import org.springframework.http.ResponseEntity;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/api/v1/batch")
@RequiredArgsConstructor
@Slf4j
@Tag(name = "Batch Operations", description = "Endpoints for triggering nightly reconciliation batch jobs")
public class BatchJobScheduler {

    private final JobLauncher jobLauncher;
    private final Job nightlyPoolEvaluationJob;

    // Nightly at 00:00 IST (cron expression for midnight)
    @Scheduled(cron = "0 0 0 * * *", zone = "Asia/Kolkata")
    public void runNightlyPoolEvaluationScheduled() {
        log.info("[SCHEDULER] Triggering scheduled nightly pool evaluation...");
        triggerJob();
    }

    @PostMapping("/trigger-nightly-evaluation")
    @Operation(summary = "Manually trigger the nightly pool evaluation and reconciliation batch job")
    public ResponseEntity<ApiResponse<String>> triggerManualEvaluation() {
        try {
            triggerJob();
            return ResponseEntity.ok(ApiResponse.ok("Nightly pool evaluation batch job executed successfully", "Batch Job Complete"));
        } catch (Exception e) {
            log.error("Failed to execute batch job", e);
            return ResponseEntity.internalServerError().body(ApiResponse.error("Failed to run batch job: " + e.getMessage()));
        }
    }

    private void triggerJob() {
        try {
            JobParameters params = new JobParametersBuilder()
                    .addLong("timestamp", System.currentTimeMillis())
                    .toJobParameters();
            jobLauncher.run(nightlyPoolEvaluationJob, params);
        } catch (Exception e) {
            throw new RuntimeException("Error launching batch job: " + e.getMessage(), e);
        }
    }
}
