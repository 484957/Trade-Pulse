package com.tradepulse.batch.service;

import lombok.extern.slf4j.Slf4j;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Service;

import java.math.BigDecimal;
import java.util.UUID;

@Service
@Slf4j
public class AsyncNotificationService {

    @Async
    public void notifyTierUnlockedAsync(UUID merchantId, String poolTitle, int tierLevel, BigDecimal newPrice) {
        // Simulates async webhook / WhatsApp message dispatch (e.g., via Gupshup / Twilio)
        log.info("[ASYNC-NOTIFY] WhatsApp dispatch to Merchant {}: Great news! Pool '{}' unlocked Tier-{}! New Wholesale Price: INR {}",
                merchantId, poolTitle, tierLevel, newPrice);
    }

    @Async
    public void notifyPoolExpiredAsync(UUID merchantId, String poolTitle, BigDecimal refundedAmount) {
        log.info("[ASYNC-NOTIFY] SMS dispatch to Merchant {}: Pool '{}' did not reach minimum MOQ. Escrow hold of INR {} has been fully refunded to your wallet.",
                merchantId, poolTitle, refundedAmount);
    }

    @Async
    public void notifyDeliveryDispatchedAsync(UUID merchantId, String invoiceNumber, String routeCluster, String otp) {
        log.info("[ASYNC-NOTIFY] WhatsApp dispatch to Merchant {}: Your consignment for Invoice {} is OUT FOR DELIVERY in cluster {}. Your delivery verification OTP is: {}",
                merchantId, invoiceNumber, routeCluster, otp);
    }
}
