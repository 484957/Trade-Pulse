package com.tradepulse.fulfillment.repository;

import com.tradepulse.fulfillment.entity.DeliveryManifestItem;
import com.tradepulse.fulfillment.entity.DispatchStatus;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;
import java.util.UUID;

@Repository
public interface DeliveryManifestItemRepository extends JpaRepository<DeliveryManifestItem, UUID> {
    List<DeliveryManifestItem> findAllByRouteClusterAndDispatchStatus(String routeCluster, DispatchStatus status);
    Optional<DeliveryManifestItem> findBySubInvoiceId(UUID subInvoiceId);
}
