package com.tradepulse.fulfillment.repository;

import com.tradepulse.fulfillment.entity.SubInvoice;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;
import java.util.UUID;

@Repository
public interface SubInvoiceRepository extends JpaRepository<SubInvoice, UUID> {
    List<SubInvoice> findAllByTenantId(UUID tenantId);
    List<SubInvoice> findAllByMasterPoId(UUID masterPoId);
    List<SubInvoice> findAllByMerchantId(UUID merchantId);
    List<SubInvoice> findAllByTenantIdAndMerchantId(UUID tenantId, UUID merchantId);
    Optional<SubInvoice> findByInvoiceNumber(String invoiceNumber);
    Optional<SubInvoice> findByCommitmentId(UUID commitmentId);
    Optional<SubInvoice> findByIdAndTenantId(UUID id, UUID tenantId);
}
