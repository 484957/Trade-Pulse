package com.tradepulse.fulfillment.controller;

import com.tradepulse.common.response.ApiResponse;
import com.tradepulse.fulfillment.dto.FulfillmentDto;
import com.tradepulse.fulfillment.entity.DeliveryManifestItem;
import com.tradepulse.fulfillment.entity.MasterPurchaseOrder;
import com.tradepulse.fulfillment.entity.SubInvoice;
import com.tradepulse.fulfillment.repository.DeliveryManifestItemRepository;
import com.tradepulse.fulfillment.repository.MasterPurchaseOrderRepository;
import com.tradepulse.fulfillment.repository.SubInvoiceRepository;
import com.tradepulse.fulfillment.service.PodVerificationService;
import com.tradepulse.fulfillment.service.SplitDeliveryAndInvoicingService;
import com.tradepulse.security.auth.AuthorizationUtils;
import com.tradepulse.security.auth.CurrentUserContext;
import com.tradepulse.tenant.context.TenantContext;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.AccessDeniedException;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.UUID;
import java.util.stream.Collectors;

@RestController
@RequestMapping("/api/v1/fulfillment")
@RequiredArgsConstructor
@Tag(name = "Fulfillment & Invoicing", description = "Endpoints for Master PO generation, Split-Invoicing, and e-POD verification")
public class FulfillmentController {

    private final SplitDeliveryAndInvoicingService splitDeliveryService;
    private final PodVerificationService podService;
    private final MasterPurchaseOrderRepository masterPoRepository;
    private final SubInvoiceRepository subInvoiceRepository;
    private final DeliveryManifestItemRepository manifestRepository;

    @GetMapping("/pools/{poolId}/master-po")
    @Operation(summary = "Get the existing master PO and sub-invoices for a pool, if one has already been generated")
    public ResponseEntity<ApiResponse<FulfillmentDto.MasterPoResponse>> getMasterPoForPool(@PathVariable UUID poolId) {
        UUID tenantId = TenantContext.requireTenantId();

        return masterPoRepository.findByPoolIdAndTenantId(poolId, tenantId)
                .map(po -> ResponseEntity.ok(ApiResponse.ok(mapToPoResponse(po))))
                .orElseGet(() -> ResponseEntity.ok(ApiResponse.ok(null, "No master PO generated for this pool yet")));
    }

    @PostMapping("/pools/{poolId}/generate-po")
    @PreAuthorize("hasRole('ADMIN')")
    @Operation(summary = "Generate consolidated Master PO and split into merchant-level tax sub-invoices with delivery manifests")
    public ResponseEntity<ApiResponse<FulfillmentDto.MasterPoResponse>> generateMasterPo(
            @PathVariable UUID poolId) {

        UUID tenantId = TenantContext.requireTenantId();

        MasterPurchaseOrder po = splitDeliveryService.generateMasterPoAndSubInvoices(tenantId, poolId);
        return ResponseEntity.ok(ApiResponse.ok(mapToPoResponse(po), "Master PO and sub-invoices generated successfully"));
    }

    @PostMapping("/delivery/verify")
    @Operation(summary = "Verify delivery with 6-digit OTP (e-POD) and trigger automated escrow settlement")
    public ResponseEntity<ApiResponse<String>> verifyDelivery(
            @Valid @RequestBody FulfillmentDto.VerifyDeliveryRequest request) {

        UUID tenantId = TenantContext.requireTenantId();

        SubInvoice invoice = podService.verifyDeliveryAndReleaseEscrow(tenantId, request.getSubInvoiceId(), request.getOtp());
        return ResponseEntity.ok(ApiResponse.ok(
                "Delivery confirmed for invoice: " + invoice.getInvoiceNumber() + ". Escrow settled to distributor and merchant rebate refunded.",
                "Delivery verified"));
    }

    @GetMapping("/sub-invoices/merchant/{merchantId}")
    @Operation(summary = "Get all tax sub-invoices for a specific merchant (your own, or any merchant's if you're an admin)")
    public ResponseEntity<ApiResponse<List<FulfillmentDto.SubInvoiceSummary>>> getMerchantInvoices(
            @PathVariable UUID merchantId) {

        UUID tenantId = TenantContext.requireTenantId();

        boolean isSelf = merchantId.equals(CurrentUserContext.getUserId());
        if (!isSelf && !AuthorizationUtils.currentUserIsAdmin()) {
            throw new AccessDeniedException("You can only view your own invoices.");
        }

        List<SubInvoice> invoices = subInvoiceRepository.findAllByTenantIdAndMerchantId(tenantId, merchantId);
        List<FulfillmentDto.SubInvoiceSummary> summaries = invoices.stream()
                .map(this::mapToSummary)
                .collect(Collectors.toList());

        return ResponseEntity.ok(ApiResponse.ok(summaries));
    }

    private FulfillmentDto.MasterPoResponse mapToPoResponse(MasterPurchaseOrder po) {
        List<FulfillmentDto.SubInvoiceSummary> subSummaries = po.getSubInvoices().stream()
                .map(this::mapToSummary)
                .collect(Collectors.toList());

        return FulfillmentDto.MasterPoResponse.builder()
                .id(po.getId())
                .poolId(po.getPool().getId())
                .distributorId(po.getDistributorId())
                .poReference(po.getPoReference())
                .totalQuantity(po.getTotalQuantity())
                .totalGrossAmount(po.getTotalGrossAmount())
                .status(po.getStatus())
                .issuedAt(po.getIssuedAt())
                .subInvoices(subSummaries)
                .build();
    }

    private FulfillmentDto.SubInvoiceSummary mapToSummary(SubInvoice invoice) {
        DeliveryManifestItem manifest = manifestRepository.findBySubInvoiceId(invoice.getId()).orElse(null);

        return FulfillmentDto.SubInvoiceSummary.builder()
                .subInvoiceId(invoice.getId())
                .invoiceNumber(invoice.getInvoiceNumber())
                .merchantId(invoice.getMerchant().getId())
                .merchantBusinessName(invoice.getMerchant().getBusinessName())
                .clusterZone(invoice.getMerchant().getClusterZone().name())
                .quantity(invoice.getQuantity())
                .unitPrice(invoice.getUnitPrice())
                .taxableAmount(invoice.getTaxableAmount())
                .cgstAmount(invoice.getCgstAmount())
                .sgstAmount(invoice.getSgstAmount())
                .igstAmount(invoice.getIgstAmount())
                .totalAmount(invoice.getTotalAmount())
                .status(invoice.getStatus())
                .deliveryOtp(manifest != null ? manifest.getDeliveryOtp() : null)
                .dispatchStatus(manifest != null ? manifest.getDispatchStatus() : null)
                .build();
    }
}
