package com.tradepulse.fulfillment.entity;

public enum DispatchStatus {
    READY_FOR_DISPATCH,
    OUT_FOR_DELIVERY,
    DELIVERED,
    PARTIALLY_DELIVERED,
    FAILED
}
