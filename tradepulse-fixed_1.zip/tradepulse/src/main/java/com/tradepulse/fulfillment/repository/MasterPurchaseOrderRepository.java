package com.tradepulse.fulfillment.repository;

import com.tradepulse.fulfillment.entity.MasterPurchaseOrder;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;
import java.util.UUID;

@Repository
public interface MasterPurchaseOrderRepository extends JpaRepository<MasterPurchaseOrder, UUID> {
    List<MasterPurchaseOrder> findAllByTenantId(UUID tenantId);
    Optional<MasterPurchaseOrder> findByPoolId(UUID poolId);
    Optional<MasterPurchaseOrder> findByPoolIdAndTenantId(UUID poolId, UUID tenantId);
    Optional<MasterPurchaseOrder> findByPoReference(String poReference);
}
