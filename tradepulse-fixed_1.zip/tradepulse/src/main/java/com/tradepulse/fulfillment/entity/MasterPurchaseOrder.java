package com.tradepulse.fulfillment.entity;

import com.tradepulse.pool.entity.BuyingPool;
import jakarta.persistence.*;
import lombok.*;

import java.math.BigDecimal;
import java.time.Instant;
import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

@Entity
@Table(name = "master_purchase_orders")
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class MasterPurchaseOrder {

    @Id
    @GeneratedValue(strategy = GenerationType.UUID)
    private UUID id;

    @Column(name = "tenant_id", nullable = false)
    private UUID tenantId;

    @OneToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "pool_id", nullable = false)
    private BuyingPool pool;

    @Column(name = "distributor_id", nullable = false)
    private UUID distributorId;

    @Column(name = "po_reference", nullable = false, unique = true, length = 100)
    private String poReference;

    @Column(name = "total_quantity", nullable = false)
    private int totalQuantity;

    @Column(name = "total_gross_amount", nullable = false, precision = 16, scale = 2)
    private BigDecimal totalGrossAmount;

    @Column(nullable = false, length = 50)
    @Builder.Default
    private String status = "ISSUED";

    @OneToMany(mappedBy = "masterPo", cascade = CascadeType.ALL, orphanRemoval = true, fetch = FetchType.LAZY)
    @Builder.Default
    private List<SubInvoice> subInvoices = new ArrayList<>();

    @Column(name = "issued_at", nullable = false, updatable = false)
    @Builder.Default
    private Instant issuedAt = Instant.now();
}
