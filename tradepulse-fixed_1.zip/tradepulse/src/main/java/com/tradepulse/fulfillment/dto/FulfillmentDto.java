package com.tradepulse.fulfillment.dto;

import com.tradepulse.fulfillment.entity.DispatchStatus;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.math.BigDecimal;
import java.time.Instant;
import java.util.List;
import java.util.UUID;

public class FulfillmentDto {

    @Data
    @Builder
    @NoArgsConstructor
    @AllArgsConstructor
    public static class MasterPoResponse {
        private UUID id;
        private UUID poolId;
        private UUID distributorId;
        private String poReference;
        private int totalQuantity;
        private BigDecimal totalGrossAmount;
        private String status;
        private Instant issuedAt;
        private List<SubInvoiceSummary> subInvoices;
    }

    @Data
    @Builder
    @NoArgsConstructor
    @AllArgsConstructor
    public static class SubInvoiceSummary {
        private UUID subInvoiceId;
        private String invoiceNumber;
        private UUID merchantId;
        private String merchantBusinessName;
        private String clusterZone;
        private int quantity;
        private BigDecimal unitPrice;
        private BigDecimal taxableAmount;
        private BigDecimal cgstAmount;
        private BigDecimal sgstAmount;
        private BigDecimal igstAmount;
        private BigDecimal totalAmount;
        private String status;
        private String deliveryOtp; // Exposed to authorized test/driver client
        private DispatchStatus dispatchStatus;
    }

    @Data
    @Builder
    @NoArgsConstructor
    @AllArgsConstructor
    public static class VerifyDeliveryRequest {
        @NotNull(message = "Sub-invoice ID is required")
        private UUID subInvoiceId;

        @NotBlank(message = "Delivery OTP is required")
        private String otp;
    }
}
