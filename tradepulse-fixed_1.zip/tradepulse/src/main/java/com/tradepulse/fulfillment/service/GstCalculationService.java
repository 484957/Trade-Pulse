package com.tradepulse.fulfillment.service;

import lombok.Builder;
import lombok.Data;
import org.springframework.stereotype.Service;

import java.math.BigDecimal;
import java.math.RoundingMode;

@Service
public class GstCalculationService {

    public static final String MAHARASHTRA_STATE_CODE = "27";

    @Data
    @Builder
    public static class TaxBreakdown {
        private BigDecimal taxableAmount;
        private BigDecimal cgstAmount;
        private BigDecimal sgstAmount;
        private BigDecimal igstAmount;
        private BigDecimal totalGrossAmount;
    }

    public TaxBreakdown calculateGst(BigDecimal totalGrossAmount, BigDecimal gstRatePercent, String merchantGstin) {
        String merchantStateCode = (merchantGstin != null && merchantGstin.length() >= 2)
                ? merchantGstin.substring(0, 2)
                : MAHARASHTRA_STATE_CODE;

        boolean isIntraState = MAHARASHTRA_STATE_CODE.equals(merchantStateCode);

        // Taxable Value = Gross / (1 + Rate / 100)
        BigDecimal divisor = BigDecimal.ONE.add(gstRatePercent.divide(BigDecimal.valueOf(100), 6, RoundingMode.HALF_UP));
        BigDecimal taxableAmount = totalGrossAmount.divide(divisor, 2, RoundingMode.HALF_UP);
        BigDecimal totalTax = totalGrossAmount.subtract(taxableAmount);

        BigDecimal cgst = BigDecimal.ZERO;
        BigDecimal sgst = BigDecimal.ZERO;
        BigDecimal igst = BigDecimal.ZERO;

        if (isIntraState) {
            cgst = totalTax.divide(BigDecimal.valueOf(2), 2, RoundingMode.HALF_UP);
            sgst = totalTax.subtract(cgst); // Protect against 1-paisa rounding discrepancies
        } else {
            igst = totalTax;
        }

        return TaxBreakdown.builder()
                .taxableAmount(taxableAmount)
                .cgstAmount(cgst)
                .sgstAmount(sgst)
                .igstAmount(igst)
                .totalGrossAmount(totalGrossAmount)
                .build();
    }
}
