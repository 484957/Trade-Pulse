package com.tradepulse.fulfillment.service;

import com.tradepulse.common.exception.BusinessException;
import com.tradepulse.fulfillment.entity.DeliveryManifestItem;
import com.tradepulse.fulfillment.entity.DispatchStatus;
import com.tradepulse.fulfillment.entity.SubInvoice;
import com.tradepulse.fulfillment.repository.DeliveryManifestItemRepository;
import com.tradepulse.fulfillment.repository.SubInvoiceRepository;
import com.tradepulse.ledger.service.DoubleEntryLedgerService;
import com.tradepulse.pool.entity.CommitmentStatus;
import com.tradepulse.pool.entity.PoolCommitment;
import com.tradepulse.pool.repository.PoolCommitmentRepository;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.time.Instant;
import java.util.UUID;

@Service
@RequiredArgsConstructor
@Slf4j
public class PodVerificationService {

    private final SubInvoiceRepository subInvoiceRepository;
    private final DeliveryManifestItemRepository manifestRepository;
    private final PoolCommitmentRepository commitmentRepository;
    private final DoubleEntryLedgerService ledgerService;

    @Value("${app.platform.default-take-rate-percent:3.00}")
    private BigDecimal defaultTakeRatePercent;

    @Transactional
    public SubInvoice verifyDeliveryAndReleaseEscrow(UUID tenantId, UUID subInvoiceId, String enteredOtp) {
        SubInvoice subInvoice = subInvoiceRepository.findByIdAndTenantId(subInvoiceId, tenantId)
                .orElseThrow(() -> new BusinessException("Sub-invoice not found: " + subInvoiceId));

        DeliveryManifestItem manifest = manifestRepository.findBySubInvoiceId(subInvoiceId)
                .orElseThrow(() -> new BusinessException("Delivery manifest not found for sub-invoice: " + subInvoiceId));

        if (manifest.getDispatchStatus() == DispatchStatus.DELIVERED) {
            throw new BusinessException("This delivery has already been verified and settled.");
        }

        if (!manifest.getDeliveryOtp().equals(enteredOtp)) {
            throw new BusinessException("Invalid Delivery OTP. Verification failed.");
        }

        manifest.setDispatchStatus(DispatchStatus.DELIVERED);
        manifest.setDeliveredAt(Instant.now());
        manifestRepository.save(manifest);

        subInvoice.setStatus("DELIVERED");
        SubInvoice savedInvoice = subInvoiceRepository.save(subInvoice);

        // Update commitment state
        PoolCommitment commitment = subInvoice.getCommitment();
        commitment.setStatus(CommitmentStatus.SETTLED);
        commitmentRepository.save(commitment);

        // Calculate double-entry settlement amounts
        BigDecimal initialHoldAmount = commitment.getLockedUnitPrice().multiply(BigDecimal.valueOf(commitment.getQuantity()));
        BigDecimal finalTotalCost = subInvoice.getTotalAmount();

        // Platform take-rate
        BigDecimal platformFee = finalTotalCost
                .multiply(defaultTakeRatePercent)
                .divide(BigDecimal.valueOf(100), 2, RoundingMode.HALF_UP);
        BigDecimal distributorPayable = finalTotalCost.subtract(platformFee);

        String settlementRef = "SETTLE-" + subInvoice.getInvoiceNumber();

        ledgerService.settlePoolFulfillment(
                tenantId,
                subInvoice.getMerchant().getId(),
                subInvoice.getMasterPo().getDistributorId(),
                initialHoldAmount,
                distributorPayable,
                platformFee,
                settlementRef
        );

        log.info("e-POD verified successfully for invoice {}. Escrow settled.", subInvoice.getInvoiceNumber());
        return savedInvoice;
    }
}
