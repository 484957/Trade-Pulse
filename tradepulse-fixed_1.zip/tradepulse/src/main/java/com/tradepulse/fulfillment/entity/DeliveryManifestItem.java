package com.tradepulse.fulfillment.entity;

import com.fasterxml.jackson.annotation.JsonIgnore;
import jakarta.persistence.*;
import lombok.*;

import java.time.Instant;
import java.util.UUID;

@Entity
@Table(name = "delivery_manifest_items")
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class DeliveryManifestItem {

    @Id
    @GeneratedValue(strategy = GenerationType.UUID)
    private UUID id;

    @OneToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "sub_invoice_id", nullable = false)
    @JsonIgnore
    private SubInvoice subInvoice;

    @Column(name = "route_cluster", nullable = false, length = 50)
    private String routeCluster; // e.g. VASAI_WEST, VIRAR_EAST

    @Enumerated(EnumType.STRING)
    @Column(name = "dispatch_status", nullable = false, length = 50)
    @Builder.Default
    private DispatchStatus dispatchStatus = DispatchStatus.READY_FOR_DISPATCH;

    @Column(name = "delivery_otp", nullable = false, length = 10)
    private String deliveryOtp; // 6-digit OTP for e-POD

    @Column(name = "delivered_at")
    private Instant deliveredAt;

    @Column(name = "created_at", nullable = false, updatable = false)
    @Builder.Default
    private Instant createdAt = Instant.now();
}
