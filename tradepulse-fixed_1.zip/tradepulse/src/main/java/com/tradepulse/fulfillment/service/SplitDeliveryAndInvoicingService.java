package com.tradepulse.fulfillment.service;

import com.tradepulse.common.exception.BusinessException;
import com.tradepulse.fulfillment.entity.*;
import com.tradepulse.fulfillment.repository.DeliveryManifestItemRepository;
import com.tradepulse.fulfillment.repository.MasterPurchaseOrderRepository;
import com.tradepulse.fulfillment.repository.SubInvoiceRepository;
import com.tradepulse.merchant.entity.Merchant;
import com.tradepulse.merchant.repository.MerchantRepository;
import com.tradepulse.pool.entity.BuyingPool;
import com.tradepulse.pool.entity.CommitmentStatus;
import com.tradepulse.pool.entity.PoolCommitment;
import com.tradepulse.pool.entity.PoolStatus;
import com.tradepulse.pool.repository.BuyingPoolRepository;
import com.tradepulse.pool.repository.PoolCommitmentRepository;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.math.BigDecimal;
import java.security.SecureRandom;
import java.time.Instant;
import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

@Service
@RequiredArgsConstructor
@Slf4j
public class SplitDeliveryAndInvoicingService {

    private final BuyingPoolRepository poolRepository;
    private final PoolCommitmentRepository commitmentRepository;
    private final MerchantRepository merchantRepository;
    private final MasterPurchaseOrderRepository masterPoRepository;
    private final SubInvoiceRepository subInvoiceRepository;
    private final DeliveryManifestItemRepository manifestRepository;
    private final GstCalculationService gstService;

    private final SecureRandom random = new SecureRandom();

    @Transactional
    public MasterPurchaseOrder generateMasterPoAndSubInvoices(UUID tenantId, UUID poolId) {
        BuyingPool pool = poolRepository.findByIdWithLock(poolId, tenantId)
                .orElseThrow(() -> new BusinessException("Buying pool not found: " + poolId));

        if (pool.getStatus() != PoolStatus.THRESHOLD_MET && pool.getStatus() != PoolStatus.OPEN) {
            throw new BusinessException("Cannot generate Master PO. Invalid pool status: " + pool.getStatus());
        }
        if (pool.getCurrentQuantity() < pool.getTargetMoq()) {
            throw new BusinessException(String.format(
                    "Pool target MOQ not reached! Current: %d, Target: %d",
                    pool.getCurrentQuantity(), pool.getTargetMoq()));
        }

        pool.setStatus(PoolStatus.PO_ISSUED);
        poolRepository.save(pool);

        BigDecimal finalUnitPrice = pool.getCurrentUnlockedPrice();
        BigDecimal totalGross = finalUnitPrice.multiply(BigDecimal.valueOf(pool.getCurrentQuantity()));

        String poRef = "MPO-" + pool.getId().toString().substring(0, 8).toUpperCase() + "-" + System.currentTimeMillis() % 10000;

        MasterPurchaseOrder masterPo = MasterPurchaseOrder.builder()
                .tenantId(tenantId)
                .pool(pool)
                .distributorId(pool.getProduct().getDistributorId())
                .poReference(poRef)
                .totalQuantity(pool.getCurrentQuantity())
                .totalGrossAmount(totalGross)
                .status("ISSUED")
                .issuedAt(Instant.now())
                .build();

        MasterPurchaseOrder savedPo = masterPoRepository.save(masterPo);

        List<PoolCommitment> commitments = commitmentRepository.findAllByPoolIdAndStatus(poolId, CommitmentStatus.CONFIRMED);
        List<SubInvoice> subInvoices = new ArrayList<>();

        int invoiceSeq = 1;
        for (PoolCommitment commitment : commitments) {
            Merchant merchant = merchantRepository.findByIdAndTenantId(commitment.getMerchantId(), tenantId)
                    .orElseThrow(() -> new BusinessException("Merchant not found: " + commitment.getMerchantId()));

            BigDecimal subGross = finalUnitPrice.multiply(BigDecimal.valueOf(commitment.getQuantity()));
            GstCalculationService.TaxBreakdown taxes = gstService.calculateGst(
                    subGross,
                    pool.getProduct().getGstRate(),
                    merchant.getGstin()
            );

            String invoiceNum = String.format("INV-%s-%04d", poRef, invoiceSeq++);

            SubInvoice subInvoice = SubInvoice.builder()
                    .tenantId(tenantId)
                    .masterPo(savedPo)
                    .commitment(commitment)
                    .merchant(merchant)
                    .invoiceNumber(invoiceNum)
                    .quantity(commitment.getQuantity())
                    .unitPrice(finalUnitPrice)
                    .taxableAmount(taxes.getTaxableAmount())
                    .cgstAmount(taxes.getCgstAmount())
                    .sgstAmount(taxes.getSgstAmount())
                    .igstAmount(taxes.getIgstAmount())
                    .totalAmount(taxes.getTotalGrossAmount())
                    .status("GENERATED")
                    .build();

            SubInvoice savedSubInvoice = subInvoiceRepository.save(subInvoice);

            // Generate delivery manifest item with route clustering and 6-digit OTP
            String otp = String.format("%06d", random.nextInt(1000000));
            DeliveryManifestItem manifestItem = DeliveryManifestItem.builder()
                    .subInvoice(savedSubInvoice)
                    .routeCluster(merchant.getClusterZone().name())
                    .dispatchStatus(DispatchStatus.READY_FOR_DISPATCH)
                    .deliveryOtp(otp)
                    .build();

            manifestRepository.save(manifestItem);
            subInvoices.add(savedSubInvoice);

            // Update commitment settled price
            commitment.setSettledUnitPrice(finalUnitPrice);
            commitmentRepository.save(commitment);
        }

        savedPo.setSubInvoices(subInvoices);
        log.info("Master PO {} generated with {} sub-invoices for pool {}", poRef, subInvoices.size(), poolId);
        return savedPo;
    }
}
