package com.tradepulse.tenant.controller;

import com.tradepulse.common.response.ApiResponse;
import com.tradepulse.tenant.entity.Tenant;
import com.tradepulse.tenant.service.TenantService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.UUID;

@RestController
@RequestMapping("/api/v1/tenants")
@RequiredArgsConstructor
@Tag(name = "Tenant Management", description = "Manage merchant cooperatives / regional tenants on the TradePulse platform")
public class TenantController {

    private final TenantService tenantService;

    @GetMapping
    @Operation(summary = "List all active tenants (platform admin use)")
    public ResponseEntity<ApiResponse<List<Tenant>>> listTenants() {
        return ResponseEntity.ok(ApiResponse.ok(tenantService.listTenants()));
    }

    @GetMapping("/{tenantId}")
    @Operation(summary = "Get tenant by ID")
    public ResponseEntity<ApiResponse<Tenant>> getTenant(@PathVariable UUID tenantId) {
        return ResponseEntity.ok(ApiResponse.ok(tenantService.getTenant(tenantId)));
    }

    @PostMapping
    @Operation(summary = "Register a new regional merchant cooperative as a tenant")
    public ResponseEntity<ApiResponse<Tenant>> createTenant(
            @RequestParam String code,
            @RequestParam String name,
            @RequestParam(required = false, defaultValue = "27") String stateCode) {
        Tenant created = tenantService.createTenant(code, name, stateCode);
        return ResponseEntity.ok(ApiResponse.ok(created, "Tenant registered successfully"));
    }
}
