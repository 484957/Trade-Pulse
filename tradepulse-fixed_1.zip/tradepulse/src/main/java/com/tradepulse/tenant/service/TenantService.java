package com.tradepulse.tenant.service;

import com.tradepulse.common.exception.BusinessException;
import com.tradepulse.tenant.entity.Tenant;
import com.tradepulse.tenant.repository.TenantRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import java.util.UUID;

@Service
@RequiredArgsConstructor
public class TenantService {

    private final TenantRepository tenantRepository;

    public List<Tenant> listTenants() {
        return tenantRepository.findAll();
    }

    public Tenant getTenant(UUID tenantId) {
        return tenantRepository.findById(tenantId)
                .orElseThrow(() -> new BusinessException("Tenant not found: " + tenantId));
    }

    public Tenant getTenantByCode(String code) {
        return tenantRepository.findByCode(code)
                .orElseThrow(() -> new BusinessException("Tenant not found with code: " + code));
    }

    @Transactional
    public Tenant createTenant(String code, String name, String stateCode) {
        Tenant tenant = Tenant.builder()
                .code(code)
                .name(name)
                .stateCode(stateCode != null ? stateCode : "27")
                .status("ACTIVE")
                .build();
        return tenantRepository.save(tenant);
    }
}
