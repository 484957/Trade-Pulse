package com.tradepulse.tenant.context;

/**
 * Thrown when a request reaches a tenant-scoped operation without a tenant
 * having been resolved from authentication. Previously, controllers silently
 * fell back to a hardcoded demo tenant id in this situation - that fallback
 * has been removed; this exception replaces it and is mapped to HTTP 401.
 */
public class TenantContextMissingException extends RuntimeException {
    public TenantContextMissingException() {
        super("No tenant could be resolved for this request. A valid authenticated session is required.");
    }
}
