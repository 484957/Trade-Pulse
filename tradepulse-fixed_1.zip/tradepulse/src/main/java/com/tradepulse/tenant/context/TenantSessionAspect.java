package com.tradepulse.tenant.context;

import jakarta.persistence.EntityManager;
import jakarta.persistence.PersistenceContext;
import lombok.extern.slf4j.Slf4j;
import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.annotation.Around;
import org.aspectj.lang.annotation.Aspect;
import org.springframework.stereotype.Component;
import org.springframework.transaction.PlatformTransactionManager;
import org.springframework.transaction.support.TransactionTemplate;

import java.util.UUID;

/**
 * Makes the Postgres Row-Level Security policies from V3/V4 actually take
 * effect, by setting app.current_tenant_id before any controller method
 * touches the database.
 *
 * Earlier version of this aspect only fired for methods explicitly
 * annotated @Transactional, which meant any controller method that forgot
 * that annotation ran its queries with no transaction and no tenant context
 * set at all - Hibernate then throws "Query requires transaction be in
 * progress" the moment it hits a query needing one. Rather than auditing
 * every controller method by hand (and re-breaking this the next time
 * someone adds an endpoint and forgets the annotation), this now wraps
 * EVERY @RestController method in one transaction itself, driven
 * programmatically via TransactionTemplate. Any @Transactional the target
 * method or the services it calls declare will simply join this already-open
 * transaction (default REQUIRED propagation) rather than conflict with it.
 */
@Aspect
@Component
@Slf4j
public class TenantSessionAspect {

    @PersistenceContext
    private EntityManager entityManager;

    private final TransactionTemplate transactionTemplate;

    public TenantSessionAspect(PlatformTransactionManager transactionManager) {
        this.transactionTemplate = new TransactionTemplate(transactionManager);
    }

    @Around("@within(org.springframework.web.bind.annotation.RestController)")
    public Object wrapInTenantScopedTransaction(ProceedingJoinPoint joinPoint) throws Throwable {
        UUID tenantId = TenantContext.getTenantId();

        // No tenant yet (login, before a token is resolved) - nothing to
        // scope. Let the method run under whatever transactional behavior
        // it (or the services it calls) already declare on their own.
        if (tenantId == null) {
            return joinPoint.proceed();
        }

        try {
            return transactionTemplate.execute(status -> {
                entityManager.createNativeQuery("SELECT set_config('app.current_tenant_id', ?1, true)")
                        .setParameter(1, tenantId.toString())
                        .getSingleResult();
                try {
                    return joinPoint.proceed();
                } catch (RuntimeException e) {
                    throw e;
                } catch (Throwable t) {
                    throw new WrappedControllerException(t);
                }
            });
        } catch (WrappedControllerException wrapped) {
            throw wrapped.getCause();
        }
    }

    private static class WrappedControllerException extends RuntimeException {
        WrappedControllerException(Throwable cause) {
            super(cause);
        }
    }
}
