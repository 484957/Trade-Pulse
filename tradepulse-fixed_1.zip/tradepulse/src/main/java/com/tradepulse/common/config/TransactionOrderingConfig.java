package com.tradepulse.common.config;

import org.springframework.context.annotation.Configuration;
import org.springframework.transaction.annotation.EnableTransactionManagement;

/**
 * Forces the @Transactional advisor to be the OUTERMOST piece of advice
 * (order = 0, i.e. highest precedence) around any @Transactional method.
 * This matters for {@link com.tradepulse.tenant.context.TenantSessionAspect}:
 * that aspect needs to run *after* the database transaction has already
 * begun (so its SET LOCAL/set_config call lands inside the same Postgres
 * transaction as the rest of the method), which requires the transactional
 * advice to wrap around it rather than the other way around.
 */
@Configuration
@EnableTransactionManagement(order = 0)
public class TransactionOrderingConfig {
}
