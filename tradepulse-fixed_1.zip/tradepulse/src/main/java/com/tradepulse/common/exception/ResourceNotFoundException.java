package com.tradepulse.common.exception;

public class ResourceNotFoundException extends BusinessException {
    public ResourceNotFoundException(String resourceType, Object id) {
        super(String.format("%s with id '%s' was not found", resourceType, id));
    }
}
