package com.tradepulse.common.exception;

import java.math.BigDecimal;

public class InsufficientBalanceException extends BusinessException {
    public InsufficientBalanceException(String accountNumber, BigDecimal currentBalance, BigDecimal requiredAmount) {
        super(String.format("Insufficient balance in account %s. Available: %s, Required: %s",
                accountNumber, currentBalance, requiredAmount));
    }
}
