package com.tradepulse.merchant.dto;

import com.tradepulse.merchant.entity.ClusterZone;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Pattern;
import jakarta.validation.constraints.Size;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.Instant;
import java.util.UUID;

public class MerchantDto {

    @Data
    @Builder
    @NoArgsConstructor
    @AllArgsConstructor
    public static class RegisterMerchantRequest {

        @NotBlank(message = "Business name is required")
        private String businessName;

        private String tradeLicenseNumber;

        @NotBlank(message = "GSTIN is required")
        @Size(min = 15, max = 15, message = "GSTIN must be exactly 15 characters")
        private String gstin;

        @NotBlank(message = "Contact phone is required")
        @Pattern(regexp = "^[6-9]\\d{9}$", message = "Invalid Indian mobile number")
        private String contactPhone;

        @NotBlank(message = "Contact email is required")
        private String contactEmail;

        @NotBlank(message = "Password is required")
        @Size(min = 8, message = "Password must be at least 8 characters")
        private String password;

        @NotNull(message = "Cluster zone is required")
        private ClusterZone clusterZone;

        @NotBlank(message = "Address is required")
        private String addressLine;

        @NotBlank(message = "Pincode is required")
        @Pattern(regexp = "^[1-9][0-9]{5}$", message = "Invalid 6-digit Indian pincode")
        private String pincode;
    }

    @Data
    @Builder
    @NoArgsConstructor
    @AllArgsConstructor
    public static class MerchantResponse {
        private UUID id;
        private UUID tenantId;
        private String businessName;
        private String tradeLicenseNumber;
        private String gstin;
        private String contactPhone;
        private String contactEmail;
        private ClusterZone clusterZone;
        private String addressLine;
        private String pincode;
        private boolean verified;
        private Instant createdAt;
    }
}
