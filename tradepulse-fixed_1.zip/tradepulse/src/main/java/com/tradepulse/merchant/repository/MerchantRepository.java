package com.tradepulse.merchant.repository;

import com.tradepulse.merchant.entity.ClusterZone;
import com.tradepulse.merchant.entity.Merchant;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;
import java.util.UUID;

@Repository
public interface MerchantRepository extends JpaRepository<Merchant, UUID> {
    List<Merchant> findAllByTenantId(UUID tenantId);
    List<Merchant> findAllByTenantIdAndClusterZone(UUID tenantId, ClusterZone clusterZone);
    Optional<Merchant> findByIdAndTenantId(UUID id, UUID tenantId);
    Optional<Merchant> findByContactEmailIgnoreCase(String contactEmail);
}
