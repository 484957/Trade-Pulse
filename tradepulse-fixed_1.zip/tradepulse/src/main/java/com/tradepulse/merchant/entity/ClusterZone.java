package com.tradepulse.merchant.entity;

public enum ClusterZone {
    VASAI_WEST,
    VASAI_EAST,
    VIRAR_WEST,
    VIRAR_EAST,
    NALLASOPARA_WEST,
    NALLASOPARA_EAST
}
