package com.tradepulse.merchant.service;

import com.tradepulse.common.exception.BusinessException;
import com.tradepulse.merchant.dto.MerchantDto;
import com.tradepulse.merchant.entity.Merchant;
import com.tradepulse.merchant.repository.MerchantRepository;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import java.util.UUID;
import java.util.stream.Collectors;

@Service
@RequiredArgsConstructor
@Slf4j
public class MerchantService {

    private final MerchantRepository merchantRepository;
    private final PasswordEncoder passwordEncoder;

    @Transactional
    public MerchantDto.MerchantResponse registerMerchant(UUID tenantId, MerchantDto.RegisterMerchantRequest request) {
        Merchant merchant = Merchant.builder()
                .tenantId(tenantId)
                .businessName(request.getBusinessName())
                .tradeLicenseNumber(request.getTradeLicenseNumber())
                .gstin(request.getGstin())
                .contactPhone(request.getContactPhone())
                .contactEmail(request.getContactEmail())
                .passwordHash(passwordEncoder.encode(request.getPassword()))
                .clusterZone(request.getClusterZone())
                .addressLine(request.getAddressLine())
                .pincode(request.getPincode())
                .verified(false)
                .build();

        Merchant saved = merchantRepository.save(merchant);
        log.info("Registered new merchant '{}' in zone {} for tenant {}", saved.getBusinessName(), saved.getClusterZone(), tenantId);
        return mapToResponse(saved);
    }

    public List<MerchantDto.MerchantResponse> listMerchants(UUID tenantId) {
        return merchantRepository.findAllByTenantId(tenantId).stream()
                .map(this::mapToResponse)
                .collect(Collectors.toList());
    }

    public MerchantDto.MerchantResponse getMerchant(UUID tenantId, UUID merchantId) {
        Merchant merchant = merchantRepository.findByIdAndTenantId(merchantId, tenantId)
                .orElseThrow(() -> new BusinessException("Merchant not found: " + merchantId));
        return mapToResponse(merchant);
    }

    @Transactional
    public MerchantDto.MerchantResponse verifyMerchant(UUID tenantId, UUID merchantId) {
        Merchant merchant = merchantRepository.findByIdAndTenantId(merchantId, tenantId)
                .orElseThrow(() -> new BusinessException("Merchant not found: " + merchantId));
        merchant.setVerified(true);
        return mapToResponse(merchantRepository.save(merchant));
    }

    public MerchantDto.MerchantResponse mapToResponse(Merchant merchant) {
        return MerchantDto.MerchantResponse.builder()
                .id(merchant.getId())
                .tenantId(merchant.getTenantId())
                .businessName(merchant.getBusinessName())
                .tradeLicenseNumber(merchant.getTradeLicenseNumber())
                .gstin(merchant.getGstin())
                .contactPhone(merchant.getContactPhone())
                .contactEmail(merchant.getContactEmail())
                .clusterZone(merchant.getClusterZone())
                .addressLine(merchant.getAddressLine())
                .pincode(merchant.getPincode())
                .verified(merchant.isVerified())
                .createdAt(merchant.getCreatedAt())
                .build();
    }
}
