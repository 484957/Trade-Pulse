package com.tradepulse.merchant.controller;

import com.tradepulse.common.response.ApiResponse;
import com.tradepulse.merchant.dto.MerchantDto;
import com.tradepulse.merchant.service.MerchantService;
import com.tradepulse.tenant.context.TenantContext;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.UUID;

@RestController
@RequestMapping("/api/v1/merchants")
@RequiredArgsConstructor
@Tag(name = "Merchant Management", description = "Register and manage local merchants within a tenant cluster")
public class MerchantController {

    private final MerchantService merchantService;


    @GetMapping
    @Operation(summary = "List all merchants belonging to the authenticated tenant cluster")
    public ResponseEntity<ApiResponse<List<MerchantDto.MerchantResponse>>> listMerchants() {
        List<MerchantDto.MerchantResponse> merchants = merchantService.listMerchants(TenantContext.requireTenantId());
        return ResponseEntity.ok(ApiResponse.ok(merchants));
    }

    @GetMapping("/{merchantId}")
    @Operation(summary = "Get a specific merchant by ID (tenant-scoped)")
    public ResponseEntity<ApiResponse<MerchantDto.MerchantResponse>> getMerchant(@PathVariable UUID merchantId) {
        MerchantDto.MerchantResponse merchant = merchantService.getMerchant(TenantContext.requireTenantId(), merchantId);
        return ResponseEntity.ok(ApiResponse.ok(merchant));
    }

    @PostMapping
    @Operation(summary = "Register a new local merchant (kirana, restaurant, retailer) into the platform")
    public ResponseEntity<ApiResponse<MerchantDto.MerchantResponse>> registerMerchant(
            @Valid @RequestBody MerchantDto.RegisterMerchantRequest request) {
        MerchantDto.MerchantResponse created = merchantService.registerMerchant(TenantContext.requireTenantId(), request);
        return ResponseEntity.ok(ApiResponse.ok(created, "Merchant registered successfully. Pending verification."));
    }

    @PatchMapping("/{merchantId}/verify")
    @PreAuthorize("hasRole('ADMIN')")
    @Operation(summary = "Mark a merchant as KYC-verified (Admin only)")
    public ResponseEntity<ApiResponse<MerchantDto.MerchantResponse>> verifyMerchant(@PathVariable UUID merchantId) {
        MerchantDto.MerchantResponse updated = merchantService.verifyMerchant(TenantContext.requireTenantId(), merchantId);
        return ResponseEntity.ok(ApiResponse.ok(updated, "Merchant successfully verified"));
    }
}
