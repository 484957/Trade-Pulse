package com.tradepulse.pool.controller;

import com.tradepulse.common.response.ApiResponse;
import com.tradepulse.pool.dto.PoolDto;
import com.tradepulse.pool.entity.BuyingPool;
import com.tradepulse.pool.repository.BuyingPoolRepository;
import com.tradepulse.pool.service.DynamicPoolPricingService;
import com.tradepulse.tenant.context.TenantContext;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.UUID;

@RestController
@RequestMapping("/api/v1/pools")
@RequiredArgsConstructor
@Tag(name = "Dynamic Buying Pools", description = "Endpoints for creating and contributing to group-buying pools")
public class BuyingPoolController {

    private final DynamicPoolPricingService pricingService;
    private final BuyingPoolRepository poolRepository;

    @GetMapping
    @Operation(summary = "List all active buying pools for the tenant")
    public ResponseEntity<ApiResponse<List<PoolDto.PoolResponse>>> listPools() {
        UUID tenantId = TenantContext.requireTenantId();

        List<PoolDto.PoolResponse> pools = pricingService.listActivePools(tenantId);
        return ResponseEntity.ok(ApiResponse.ok(pools));
    }

    @GetMapping("/{poolId}")
    @Operation(summary = "Get live pool status, unlocked pricing tier, and progress to next slab")
    public ResponseEntity<ApiResponse<PoolDto.PoolResponse>> getPool(@PathVariable UUID poolId) {
        UUID tenantId = TenantContext.requireTenantId();

        BuyingPool pool = poolRepository.findByIdAndTenantId(poolId, tenantId)
                .orElseThrow(() -> new IllegalArgumentException("Pool not found: " + poolId));

        return ResponseEntity.ok(ApiResponse.ok(pricingService.mapToPoolResponse(pool)));
    }

    @PostMapping
    @PreAuthorize("hasRole('ADMIN')")
    @Operation(summary = "Create a new group-buying pool with volume tier slabs")
    public ResponseEntity<ApiResponse<PoolDto.PoolResponse>> createPool(
            @Valid @RequestBody PoolDto.CreatePoolRequest request) {

        UUID tenantId = TenantContext.requireTenantId();

        BuyingPool created = pricingService.createPool(tenantId, request);
        return ResponseEntity.ok(ApiResponse.ok(pricingService.mapToPoolResponse(created), "Buying pool created"));
    }

    @PostMapping("/{poolId}/commit")
    @Operation(summary = "Contribute order volume to a pool (dynamically recalculates tiers & locks escrow hold)")
    public ResponseEntity<ApiResponse<PoolDto.CommitmentResponse>> contribute(
            @PathVariable UUID poolId,
            @Valid @RequestBody PoolDto.CommitmentRequest request) {

        UUID tenantId = TenantContext.requireTenantId();

        PoolDto.CommitmentResponse response = pricingService.contributeToPool(
                tenantId,
                poolId,
                request.getMerchantId(),
                request.getQuantity()
        );

        return ResponseEntity.ok(ApiResponse.ok(response, "Order volume committed to pool successfully"));
    }
}
