package com.tradepulse.pool.repository;

import com.tradepulse.pool.entity.Product;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;
import java.util.UUID;

@Repository
public interface ProductRepository extends JpaRepository<Product, UUID> {
    List<Product> findAllByTenantId(UUID tenantId);
    Optional<Product> findByIdAndTenantId(UUID id, UUID tenantId);
    Optional<Product> findByTenantIdAndSku(UUID tenantId, String sku);
}
