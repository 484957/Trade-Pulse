package com.tradepulse.pool.dto;

import com.tradepulse.pool.entity.CommitmentStatus;
import com.tradepulse.pool.entity.PoolStatus;
import jakarta.validation.constraints.Future;
import jakarta.validation.constraints.Min;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.math.BigDecimal;
import java.time.Instant;
import java.util.List;
import java.util.UUID;

public class PoolDto {

    @Data
    @Builder
    @NoArgsConstructor
    @AllArgsConstructor
    public static class CreatePoolRequest {
        @NotNull(message = "Product ID is required")
        private UUID productId;

        @NotBlank(message = "Title is required")
        private String title;

        @Min(value = 1, message = "Target MOQ must be at least 1")
        private int targetMoq;

        @Min(value = 1, message = "Max capacity must be at least 1")
        private int maxCapacity;

        @NotNull(message = "Start time is required")
        private Instant startTime;

        @NotNull(message = "Cutoff time is required")
        @Future(message = "Cutoff time must be in the future")
        private Instant cutoffTime;

        @NotNull(message = "Freeze time is required")
        private Instant freezeTime;
    }

    @Data
    @Builder
    @NoArgsConstructor
    @AllArgsConstructor
    public static class CommitmentRequest {
        @NotNull(message = "Merchant ID is required")
        private UUID merchantId;

        @Min(value = 1, message = "Quantity must be at least 1")
        private int quantity;
    }

    @Data
    @Builder
    @NoArgsConstructor
    @AllArgsConstructor
    public static class PoolResponse {
        private UUID id;
        private UUID tenantId;
        private UUID productId;
        private String productTitle;
        private String productSku;
        private String title;
        private PoolStatus status;
        private int currentQuantity;
        private int targetMoq;
        private int maxCapacity;
        private BigDecimal currentUnlockedPrice;
        private Instant startTime;
        private Instant cutoffTime;
        private Instant freezeTime;
        private TierProgressDto tierProgress;
    }

    @Data
    @Builder
    @NoArgsConstructor
    @AllArgsConstructor
    public static class TierProgressDto {
        private Integer activeTierLevel;
        private BigDecimal activeUnitPrice;
        private Integer nextTierLevel;
        private BigDecimal nextUnitPrice;
        private Integer unitsNeededForNextTier;
        private BigDecimal estimatedSavingsPerUnit;
    }

    @Data
    @Builder
    @NoArgsConstructor
    @AllArgsConstructor
    public static class CommitmentResponse {
        private UUID commitmentId;
        private UUID poolId;
        private UUID merchantId;
        private int quantity;
        private BigDecimal lockedUnitPrice;
        private BigDecimal totalHoldAmount;
        private CommitmentStatus status;
        private Instant createdAt;
        private TierProgressDto updatedTierProgress;
    }
}
