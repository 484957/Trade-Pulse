package com.tradepulse.pool.repository;

import com.tradepulse.pool.entity.CommitmentStatus;
import com.tradepulse.pool.entity.PoolCommitment;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.UUID;

@Repository
public interface PoolCommitmentRepository extends JpaRepository<PoolCommitment, UUID> {
    List<PoolCommitment> findAllByPoolId(UUID poolId);
    List<PoolCommitment> findAllByMerchantId(UUID merchantId);
    List<PoolCommitment> findAllByPoolIdAndStatus(UUID poolId, CommitmentStatus status);
}
