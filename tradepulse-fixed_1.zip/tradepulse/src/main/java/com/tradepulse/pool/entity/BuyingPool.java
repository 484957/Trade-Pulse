package com.tradepulse.pool.entity;

import jakarta.persistence.*;
import lombok.*;

import java.math.BigDecimal;
import java.time.Instant;
import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

@Entity
@Table(name = "buying_pools")
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class BuyingPool {

    @Id
    @GeneratedValue(strategy = GenerationType.UUID)
    private UUID id;

    @Column(name = "tenant_id", nullable = false)
    private UUID tenantId;

    @ManyToOne(fetch = FetchType.EAGER)
    @JoinColumn(name = "product_id", nullable = false)
    private Product product;

    @Column(nullable = false)
    private String title;

    @Enumerated(EnumType.STRING)
    @Column(nullable = false, length = 50)
    @Builder.Default
    private PoolStatus status = PoolStatus.OPEN;

    @Column(name = "current_quantity", nullable = false)
    @Builder.Default
    private int currentQuantity = 0;

    @Column(name = "target_moq", nullable = false)
    private int targetMoq;

    @Column(name = "max_capacity", nullable = false)
    private int maxCapacity;

    @Column(name = "current_unlocked_price", nullable = false, precision = 12, scale = 2)
    private BigDecimal currentUnlockedPrice;

    @Column(name = "start_time", nullable = false)
    private Instant startTime;

    @Column(name = "cutoff_time", nullable = false)
    private Instant cutoffTime;

    @Column(name = "freeze_time", nullable = false)
    private Instant freezeTime;

    @OneToMany(mappedBy = "pool", cascade = CascadeType.ALL, fetch = FetchType.LAZY)
    @Builder.Default
    private List<PoolCommitment> commitments = new ArrayList<>();

    @Version
    @Column(nullable = false)
    @Builder.Default
    private Long version = 0L;

    @Column(name = "created_at", nullable = false, updatable = false)
    @Builder.Default
    private Instant createdAt = Instant.now();

    public boolean isOpenForCommitment() {
        Instant now = Instant.now();
        return (status == PoolStatus.OPEN || status == PoolStatus.THRESHOLD_MET)
                && now.isAfter(startTime)
                && now.isBefore(cutoffTime);
    }

    public boolean isWithinFreezeWindow() {
        return Instant.now().isAfter(freezeTime);
    }

    public ProductTier evaluateTierForQuantity(int quantity) {
        if (product == null || product.getTiers() == null || product.getTiers().isEmpty()) {
            return null;
        }

        ProductTier matchedTier = null;
        for (ProductTier tier : product.getTiers()) {
            if (quantity >= tier.getMinVolumeThreshold()) {
                if (matchedTier == null || tier.getMinVolumeThreshold() > matchedTier.getMinVolumeThreshold()) {
                    matchedTier = tier;
                }
            }
        }
        return matchedTier;
    }

    public ProductTier getNextHigherTier(int quantity) {
        if (product == null || product.getTiers() == null) {
            return null;
        }
        ProductTier currentTier = evaluateTierForQuantity(quantity);
        int currentThreshold = (currentTier != null) ? currentTier.getMinVolumeThreshold() : -1;

        ProductTier nextTier = null;
        for (ProductTier tier : product.getTiers()) {
            if (tier.getMinVolumeThreshold() > currentThreshold) {
                if (nextTier == null || tier.getMinVolumeThreshold() < nextTier.getMinVolumeThreshold()) {
                    nextTier = tier;
                }
            }
        }
        return nextTier;
    }
}
