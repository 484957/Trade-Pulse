package com.tradepulse.pool.entity;

public enum CommitmentStatus {
    HOLD_PENDING,
    CONFIRMED,
    SETTLED,
    CANCELLED,
    REFUNDED
}
