package com.tradepulse.pool.controller;

import com.tradepulse.common.response.ApiResponse;
import com.tradepulse.pool.entity.Product;
import com.tradepulse.pool.entity.ProductTier;
import com.tradepulse.pool.service.ProductService;
import com.tradepulse.tenant.context.TenantContext;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.UUID;

@RestController
@RequestMapping("/api/v1/products")
@RequiredArgsConstructor
@Tag(name = "Product Catalog", description = "Manage distributor products and their volume-based pricing tiers")
public class ProductController {

    private final ProductService productService;


    @GetMapping
    @Operation(summary = "List all products available for group-buying pools in this tenant")
    public ResponseEntity<ApiResponse<List<Product>>> listProducts() {
        return ResponseEntity.ok(ApiResponse.ok(productService.listProducts(TenantContext.requireTenantId())));
    }

    @GetMapping("/{productId}")
    @Operation(summary = "Get full product details including all pricing tiers")
    public ResponseEntity<ApiResponse<Product>> getProduct(@PathVariable UUID productId) {
        return ResponseEntity.ok(ApiResponse.ok(productService.getProduct(TenantContext.requireTenantId(), productId)));
    }

    @GetMapping("/{productId}/tiers")
    @Operation(summary = "Get all pricing tiers for a product ordered by volume threshold ascending")
    public ResponseEntity<ApiResponse<List<ProductTier>>> getProductTiers(@PathVariable UUID productId) {
        UUID tenantId = TenantContext.requireTenantId();
        // getProduct() throws if the product doesn't belong to this tenant,
        // so this can't be used to read another tenant's pricing tiers by ID.
        productService.getProduct(tenantId, productId);
        List<ProductTier> tiers = productService.listTiersForProduct(productId);
        return ResponseEntity.ok(ApiResponse.ok(tiers));
    }

    @PostMapping
    @PreAuthorize("hasRole('ADMIN')")
    @Operation(summary = "Register a new distributor product into the product catalog")
    public ResponseEntity<ApiResponse<Product>> createProduct(@RequestBody Product product) {
        Product created = productService.createProduct(TenantContext.requireTenantId(), product);
        return ResponseEntity.ok(ApiResponse.ok(created, "Product registered successfully"));
    }

    @PostMapping("/{productId}/tiers")
    @PreAuthorize("hasRole('ADMIN')")
    @Operation(summary = "Add a new volume pricing tier to an existing product")
    public ResponseEntity<ApiResponse<ProductTier>> addTier(
            @PathVariable UUID productId,
            @RequestBody ProductTier tier) {
        ProductTier created = productService.addTier(TenantContext.requireTenantId(), productId, tier);
        return ResponseEntity.ok(ApiResponse.ok(created, "Pricing tier added successfully"));
    }
}
