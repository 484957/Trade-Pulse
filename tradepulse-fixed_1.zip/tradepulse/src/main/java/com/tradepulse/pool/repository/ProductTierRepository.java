package com.tradepulse.pool.repository;

import com.tradepulse.pool.entity.ProductTier;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.UUID;

@Repository
public interface ProductTierRepository extends JpaRepository<ProductTier, UUID> {
    List<ProductTier> findAllByProductIdOrderByMinVolumeThresholdAsc(UUID productId);
}
