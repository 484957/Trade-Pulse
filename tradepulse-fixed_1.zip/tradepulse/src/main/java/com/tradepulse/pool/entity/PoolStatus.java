package com.tradepulse.pool.entity;

public enum PoolStatus {
    DRAFT,
    OPEN,
    THRESHOLD_MET,
    LOCKED,
    PO_ISSUED,
    FULFILLED,
    EXPIRED
}
