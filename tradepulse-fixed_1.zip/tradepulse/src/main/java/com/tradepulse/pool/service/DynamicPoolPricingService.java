package com.tradepulse.pool.service;

import com.tradepulse.common.exception.BusinessException;
import com.tradepulse.ledger.service.DoubleEntryLedgerService;
import com.tradepulse.pool.dto.PoolDto;
import com.tradepulse.pool.entity.*;
import com.tradepulse.pool.repository.BuyingPoolRepository;
import com.tradepulse.pool.repository.PoolCommitmentRepository;
import com.tradepulse.pool.repository.ProductRepository;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Isolation;
import org.springframework.transaction.annotation.Transactional;

import java.math.BigDecimal;
import java.time.Instant;
import java.util.List;
import java.util.UUID;
import java.util.stream.Collectors;

@Service
@RequiredArgsConstructor
@Slf4j
public class DynamicPoolPricingService {

    private final BuyingPoolRepository poolRepository;
    private final PoolCommitmentRepository commitmentRepository;
    private final ProductRepository productRepository;
    private final DoubleEntryLedgerService ledgerService;

    @Transactional
    public BuyingPool createPool(UUID tenantId, PoolDto.CreatePoolRequest request) {
        Product product = productRepository.findByIdAndTenantId(request.getProductId(), tenantId)
                .orElseThrow(() -> new BusinessException("Product not found: " + request.getProductId()));

        if (request.getStartTime().isAfter(request.getCutoffTime())) {
            throw new BusinessException("Start time cannot be after cutoff time");
        }
        if (request.getFreezeTime().isAfter(request.getCutoffTime())) {
            throw new BusinessException("Freeze time cannot be after cutoff time");
        }

        // Base price is highest tier or MRP
        BigDecimal initialPrice = product.getTiers().stream()
                .findFirst()
                .map(ProductTier::getUnitPrice)
                .orElse(product.getMrp());

        BuyingPool pool = BuyingPool.builder()
                .tenantId(tenantId)
                .product(product)
                .title(request.getTitle())
                .status(PoolStatus.OPEN)
                .currentQuantity(0)
                .targetMoq(request.getTargetMoq())
                .maxCapacity(request.getMaxCapacity())
                .currentUnlockedPrice(initialPrice)
                .startTime(request.getStartTime())
                .cutoffTime(request.getCutoffTime())
                .freezeTime(request.getFreezeTime())
                .build();

        return poolRepository.save(pool);
    }

    @Transactional(isolation = Isolation.REPEATABLE_READ)
    public PoolDto.CommitmentResponse contributeToPool(UUID tenantId, UUID poolId, UUID merchantId, int quantity) {
        BuyingPool pool = poolRepository.findByIdWithLock(poolId, tenantId)
                .orElseThrow(() -> new BusinessException("Buying pool not found: " + poolId));

        if (!pool.isOpenForCommitment()) {
            throw new BusinessException("Pool is currently not open for commitments. Status: " + pool.getStatus());
        }

        int newTotalQuantity = pool.getCurrentQuantity() + quantity;
        if (newTotalQuantity > pool.getMaxCapacity()) {
            throw new BusinessException(String.format(
                    "Commitment of %d units exceeds pool max capacity of %d (current: %d)",
                    quantity, pool.getMaxCapacity(), pool.getCurrentQuantity()));
        }

        // Evaluate dynamic tier based on new total volume
        ProductTier unlockedTier = pool.evaluateTierForQuantity(newTotalQuantity);
        BigDecimal lockedUnitPrice = (unlockedTier != null)
                ? unlockedTier.getUnitPrice()
                : pool.getCurrentUnlockedPrice();

        BigDecimal totalHoldAmount = lockedUnitPrice.multiply(BigDecimal.valueOf(quantity));

        // Lock Escrow Hold in Ledger (Atomic ACID check)
        String escrowRef = "ESC-HOLD-" + poolId.toString().substring(0, 8) + "-" + UUID.randomUUID().toString().substring(0, 6);
        ledgerService.lockEscrowHold(tenantId, merchantId, totalHoldAmount, escrowRef);

        // Record Commitment
        PoolCommitment commitment = PoolCommitment.builder()
                .pool(pool)
                .merchantId(merchantId)
                .quantity(quantity)
                .lockedUnitPrice(lockedUnitPrice)
                .status(CommitmentStatus.CONFIRMED)
                .build();

        PoolCommitment savedCommitment = commitmentRepository.save(commitment);

        // Update pool state
        pool.setCurrentQuantity(newTotalQuantity);
        pool.setCurrentUnlockedPrice(lockedUnitPrice);

        if (newTotalQuantity >= pool.getTargetMoq() && pool.getStatus() == PoolStatus.OPEN) {
            pool.setStatus(PoolStatus.THRESHOLD_MET);
            log.info("Pool {} reached MOQ threshold! Quantity: {}", pool.getId(), newTotalQuantity);
        }

        BuyingPool savedPool = poolRepository.save(pool);

        PoolDto.TierProgressDto tierProgress = calculateTierProgress(savedPool);

        return PoolDto.CommitmentResponse.builder()
                .commitmentId(savedCommitment.getId())
                .poolId(savedPool.getId())
                .merchantId(merchantId)
                .quantity(quantity)
                .lockedUnitPrice(lockedUnitPrice)
                .totalHoldAmount(totalHoldAmount)
                .status(savedCommitment.getStatus())
                .createdAt(savedCommitment.getCreatedAt())
                .updatedTierProgress(tierProgress)
                .build();
    }

    public PoolDto.TierProgressDto calculateTierProgress(BuyingPool pool) {
        ProductTier activeTier = pool.evaluateTierForQuantity(pool.getCurrentQuantity());
        ProductTier nextTier = pool.getNextHigherTier(pool.getCurrentQuantity());

        Integer activeLevel = activeTier != null ? activeTier.getTierLevel() : null;
        BigDecimal activePrice = activeTier != null ? activeTier.getUnitPrice() : pool.getProduct().getMrp();

        Integer nextLevel = nextTier != null ? nextTier.getTierLevel() : null;
        BigDecimal nextPrice = nextTier != null ? nextTier.getUnitPrice() : null;
        Integer unitsNeeded = nextTier != null ? nextTier.getMinVolumeThreshold() - pool.getCurrentQuantity() : null;
        BigDecimal savingsPerUnit = (nextPrice != null) ? activePrice.subtract(nextPrice) : null;

        return PoolDto.TierProgressDto.builder()
                .activeTierLevel(activeLevel)
                .activeUnitPrice(activePrice)
                .nextTierLevel(nextLevel)
                .nextUnitPrice(nextPrice)
                .unitsNeededForNextTier(unitsNeeded)
                .estimatedSavingsPerUnit(savingsPerUnit)
                .build();
    }

    public PoolDto.PoolResponse mapToPoolResponse(BuyingPool pool) {
        return PoolDto.PoolResponse.builder()
                .id(pool.getId())
                .tenantId(pool.getTenantId())
                .productId(pool.getProduct().getId())
                .productTitle(pool.getProduct().getTitle())
                .productSku(pool.getProduct().getSku())
                .title(pool.getTitle())
                .status(pool.getStatus())
                .currentQuantity(pool.getCurrentQuantity())
                .targetMoq(pool.getTargetMoq())
                .maxCapacity(pool.getMaxCapacity())
                .currentUnlockedPrice(pool.getCurrentUnlockedPrice())
                .startTime(pool.getStartTime())
                .cutoffTime(pool.getCutoffTime())
                .freezeTime(pool.getFreezeTime())
                .tierProgress(calculateTierProgress(pool))
                .build();
    }

    public List<PoolDto.PoolResponse> listActivePools(UUID tenantId) {
        return poolRepository.findAllByTenantId(tenantId).stream()
                .map(this::mapToPoolResponse)
                .collect(Collectors.toList());
    }
}
