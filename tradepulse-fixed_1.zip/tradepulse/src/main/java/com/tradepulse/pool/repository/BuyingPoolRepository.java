package com.tradepulse.pool.repository;

import com.tradepulse.pool.entity.BuyingPool;
import com.tradepulse.pool.entity.PoolStatus;
import jakarta.persistence.LockModeType;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Lock;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.time.Instant;
import java.util.List;
import java.util.Optional;
import java.util.UUID;

@Repository
public interface BuyingPoolRepository extends JpaRepository<BuyingPool, UUID> {

    List<BuyingPool> findAllByTenantId(UUID tenantId);

    Optional<BuyingPool> findByIdAndTenantId(UUID id, UUID tenantId);

    List<BuyingPool> findAllByTenantIdAndStatus(UUID tenantId, PoolStatus status);

    @Lock(LockModeType.PESSIMISTIC_WRITE)
    @Query("SELECT p FROM BuyingPool p WHERE p.id = :id AND p.tenantId = :tenantId")
    Optional<BuyingPool> findByIdWithLock(@Param("id") UUID id, @Param("tenantId") UUID tenantId);

    @Query("SELECT p FROM BuyingPool p WHERE p.status IN ('OPEN', 'THRESHOLD_MET') AND p.cutoffTime <= :now")
    List<BuyingPool> findExpiredOpenPools(@Param("now") Instant now);
}
