package com.tradepulse.pool.service;

import com.tradepulse.common.exception.BusinessException;
import com.tradepulse.pool.entity.Product;
import com.tradepulse.pool.entity.ProductTier;
import com.tradepulse.pool.repository.ProductRepository;
import com.tradepulse.pool.repository.ProductTierRepository;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import java.util.UUID;

@Service
@RequiredArgsConstructor
@Slf4j
public class ProductService {

    private final ProductRepository productRepository;
    private final ProductTierRepository tierRepository;

    public List<Product> listProducts(UUID tenantId) {
        return productRepository.findAllByTenantId(tenantId);
    }

    public Product getProduct(UUID tenantId, UUID productId) {
        return productRepository.findByIdAndTenantId(productId, tenantId)
                .orElseThrow(() -> new BusinessException("Product not found: " + productId));
    }

    @Transactional
    public Product createProduct(UUID tenantId, Product product) {
        product.setTenantId(tenantId);
        Product saved = productRepository.save(product);
        log.info("Created product '{}' with SKU {} for tenant {}", saved.getTitle(), saved.getSku(), tenantId);
        return saved;
    }

    @Transactional
    public ProductTier addTier(UUID tenantId, UUID productId, ProductTier tier) {
        Product product = getProduct(tenantId, productId);
        tier.setProduct(product);
        return tierRepository.save(tier);
    }

    public List<ProductTier> listTiersForProduct(UUID productId) {
        return tierRepository.findAllByProductIdOrderByMinVolumeThresholdAsc(productId);
    }
}
