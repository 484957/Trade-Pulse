-- ============================================================================
-- V4: Fix login being locked out by the merchants RLS policy added in V3
--
-- Login has to look a merchant up by email BEFORE any tenant is known (that
-- lookup is what determines the tenant). With app.current_tenant_id unset,
-- V3's policy matched zero rows for every query - including login - so
-- authentication always failed with "Invalid username or password" even
-- with the correct password.
--
-- Fix: allow this table's policy to also pass when a narrow, code-only
-- session flag (app.bypass_tenant_check) is set to 'true'. This flag can
-- only ever be set from inside the application's own Java code
-- (AuthMerchantLookupService) for the single duration of the login lookup's
-- transaction - a client sending HTTP requests has no way to set a Postgres
-- session variable on the server's own database connection, so this does
-- not reopen the tenant-isolation gap V3 was meant to close.
-- ============================================================================

DROP POLICY IF EXISTS tenant_isolation_policy ON merchants;

CREATE POLICY tenant_isolation_policy ON merchants
    USING (
        tenant_id = current_setting('app.current_tenant_id', true)::uuid
        OR current_setting('app.bypass_tenant_check', true) = 'true'
    )
    WITH CHECK (
        tenant_id = current_setting('app.current_tenant_id', true)::uuid
        OR current_setting('app.bypass_tenant_check', true) = 'true'
    );
