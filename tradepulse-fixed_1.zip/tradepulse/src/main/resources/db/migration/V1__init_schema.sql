-- ============================================================================
-- TRADEPULSE DATABASE INITIALIZATION DDL
-- Compatible with PostgreSQL 15+
-- ============================================================================

CREATE EXTENSION IF NOT EXISTS "uuid-ossp";

-- 1. TENANTS & MERCHANTS
CREATE TABLE IF NOT EXISTS tenants (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    code VARCHAR(50) UNIQUE NOT NULL,
    name VARCHAR(255) NOT NULL,
    state_code VARCHAR(2) NOT NULL DEFAULT '27',
    status VARCHAR(30) NOT NULL DEFAULT 'ACTIVE',
    created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS merchants (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    tenant_id UUID NOT NULL REFERENCES tenants(id),
    business_name VARCHAR(255) NOT NULL,
    trade_license_number VARCHAR(100),
    gstin VARCHAR(15) NOT NULL,
    contact_phone VARCHAR(20) NOT NULL,
    contact_email VARCHAR(255) NOT NULL,
    cluster_zone VARCHAR(50) NOT NULL,
    address_line VARCHAR(255) NOT NULL,
    pincode VARCHAR(10) NOT NULL,
    is_verified BOOLEAN NOT NULL DEFAULT FALSE,
    created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT CURRENT_TIMESTAMP,
    version BIGINT NOT NULL DEFAULT 0
);

-- 2. PRODUCTS & PRICING TIERS
CREATE TABLE IF NOT EXISTS products (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    tenant_id UUID NOT NULL REFERENCES tenants(id),
    distributor_id UUID NOT NULL,
    sku VARCHAR(100) NOT NULL,
    title VARCHAR(255) NOT NULL,
    hsn_code VARCHAR(10) NOT NULL,
    gst_rate NUMERIC(5,2) NOT NULL,
    base_unit VARCHAR(20) NOT NULL,
    mrp NUMERIC(12,2) NOT NULL,
    created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS product_tiers (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    product_id UUID NOT NULL REFERENCES products(id) ON DELETE CASCADE,
    tier_level INT NOT NULL,
    min_volume_threshold INT NOT NULL,
    unit_price NUMERIC(12,2) NOT NULL
);

-- 3. BUYING POOLS & COMMITMENTS
CREATE TABLE IF NOT EXISTS buying_pools (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    tenant_id UUID NOT NULL REFERENCES tenants(id),
    product_id UUID NOT NULL REFERENCES products(id),
    title VARCHAR(255) NOT NULL,
    status VARCHAR(50) NOT NULL DEFAULT 'OPEN',
    current_quantity INT NOT NULL DEFAULT 0,
    target_moq INT NOT NULL,
    max_capacity INT NOT NULL,
    current_unlocked_price NUMERIC(12,2) NOT NULL,
    start_time TIMESTAMP WITH TIME ZONE NOT NULL,
    cutoff_time TIMESTAMP WITH TIME ZONE NOT NULL,
    freeze_time TIMESTAMP WITH TIME ZONE NOT NULL,
    version BIGINT NOT NULL DEFAULT 0,
    created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS pool_commitments (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    pool_id UUID NOT NULL REFERENCES buying_pools(id),
    merchant_id UUID NOT NULL REFERENCES merchants(id),
    quantity INT NOT NULL,
    locked_unit_price NUMERIC(12,2) NOT NULL,
    settled_unit_price NUMERIC(12,2),
    status VARCHAR(50) NOT NULL DEFAULT 'HOLD_PENDING',
    created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT CURRENT_TIMESTAMP,
    version BIGINT NOT NULL DEFAULT 0
);

-- 4. DOUBLE-ENTRY LEDGER & ESCROW
CREATE TABLE IF NOT EXISTS accounts (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    tenant_id UUID NOT NULL REFERENCES tenants(id),
    owner_id UUID NOT NULL,
    account_number VARCHAR(100) UNIQUE NOT NULL,
    account_type VARCHAR(50) NOT NULL,
    currency VARCHAR(3) NOT NULL DEFAULT 'INR',
    cached_balance NUMERIC(16,2) NOT NULL DEFAULT 0.00,
    version BIGINT NOT NULL DEFAULT 0,
    is_active BOOLEAN NOT NULL DEFAULT TRUE,
    created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS journal_transactions (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    tenant_id UUID NOT NULL REFERENCES tenants(id),
    transaction_ref VARCHAR(100) UNIQUE NOT NULL,
    event_type VARCHAR(100) NOT NULL,
    description TEXT,
    posted_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS ledger_entries (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    transaction_id UUID NOT NULL REFERENCES journal_transactions(id),
    account_id UUID NOT NULL REFERENCES accounts(id),
    entry_type VARCHAR(10) NOT NULL,
    amount NUMERIC(16,2) NOT NULL,
    created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT CURRENT_TIMESTAMP
);

-- 5. FULFILLMENT & SUB-INVOICES
CREATE TABLE IF NOT EXISTS master_purchase_orders (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    tenant_id UUID NOT NULL REFERENCES tenants(id),
    pool_id UUID NOT NULL REFERENCES buying_pools(id),
    distributor_id UUID NOT NULL,
    po_reference VARCHAR(100) UNIQUE NOT NULL,
    total_quantity INT NOT NULL,
    total_gross_amount NUMERIC(16,2) NOT NULL,
    status VARCHAR(50) NOT NULL DEFAULT 'ISSUED',
    issued_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS sub_invoices (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    tenant_id UUID NOT NULL REFERENCES tenants(id),
    master_po_id UUID NOT NULL REFERENCES master_purchase_orders(id),
    commitment_id UUID NOT NULL REFERENCES pool_commitments(id),
    merchant_id UUID NOT NULL REFERENCES merchants(id),
    invoice_number VARCHAR(100) UNIQUE NOT NULL,
    quantity INT NOT NULL,
    unit_price NUMERIC(12,2) NOT NULL,
    taxable_amount NUMERIC(14,2) NOT NULL,
    cgst_amount NUMERIC(12,2) NOT NULL,
    sgst_amount NUMERIC(12,2) NOT NULL,
    igst_amount NUMERIC(12,2) NOT NULL DEFAULT 0.00,
    total_amount NUMERIC(14,2) NOT NULL,
    status VARCHAR(50) NOT NULL DEFAULT 'GENERATED',
    created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS delivery_manifest_items (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    sub_invoice_id UUID NOT NULL REFERENCES sub_invoices(id),
    route_cluster VARCHAR(50) NOT NULL,
    dispatch_status VARCHAR(50) NOT NULL DEFAULT 'READY_FOR_DISPATCH',
    delivery_otp VARCHAR(10) NOT NULL,
    delivered_at TIMESTAMP WITH TIME ZONE,
    created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT CURRENT_TIMESTAMP
);
