-- ============================================================================
-- V5: Real admin role
--
-- Until now, "admin" endpoints (product/tier management, pool creation,
-- merchant verification, PO generation) had no actual authorization check -
-- any authenticated merchant's token could call them. This adds a real
-- is_admin flag and seeds one dedicated ops/admin account so there's a
-- genuine distinction between "a merchant shopping in pools" and "staff
-- running the platform" to log in and test against.
--
-- Note: modeling admin as a flag on the merchants table is a pragmatic
-- shortcut, not the ideal long-term shape - a real system would likely give
-- staff their own identity table entirely, separate from merchant accounts.
-- This is good enough to make the authorization check real; revisit if
-- staff ever need permissions merchants should never have at all.
-- ============================================================================

ALTER TABLE merchants ADD COLUMN IF NOT EXISTS is_admin BOOLEAN NOT NULL DEFAULT false;

INSERT INTO merchants (
    id, tenant_id, business_name, trade_license_number, gstin, contact_phone,
    contact_email, password_hash, cluster_zone, address_line, pincode,
    is_verified, is_admin, version
)
VALUES (
    'c1d2e3f4-0000-0000-0000-000000000099',
    'a1b2c3d4-0000-0000-0000-000000000001',
    'TradePulse Ops',
    NULL,
    '27ADMIN0000A1Z5',
    '9800000000',
    'ops@tradepulse.io',
    -- bcrypt hash of "AdminPass123!"
    '$2b$10$./iy9/NBvxImNw7xEXnOouClNrpr2RSJKk5l4.e6x2r8m/S9xxNlq',
    'VASAI_WEST',
    'TradePulse Operations Office, Vasai Road',
    '401202',
    true,
    true,
    0
)
ON CONFLICT (contact_email) DO NOTHING;
