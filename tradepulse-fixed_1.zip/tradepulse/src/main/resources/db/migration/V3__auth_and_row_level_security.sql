-- ============================================================================
-- V3: Real merchant authentication + Postgres Row-Level Security
--
-- Fixes two issues found in review:
--  1. Merchants had no credential to authenticate against (login accepted any
--     password). This adds a password_hash column.
--  2. The README claimed tenant isolation was enforced via Postgres RLS using
--     SET LOCAL app.current_tenant_id, but no RLS policy existed anywhere in
--     the schema. This creates the policies and turns RLS on. The app side
--     now actually sets app.current_tenant_id per transaction (see
--     TenantSessionAspect) for this to take effect.
-- ============================================================================

-- 1. Merchant credentials -----------------------------------------------------
ALTER TABLE merchants ADD COLUMN IF NOT EXISTS password_hash VARCHAR(100);

-- Backfill the two seeded demo merchants with BCrypt hash of "Password123!"
-- (the password already documented in the project README's walkthrough).
UPDATE merchants
SET password_hash = '$2b$10$6SuKjVYggNciactqq7/z7enC3U7wVdlHyK3MYpNia0STFoeE7hqj6'
WHERE password_hash IS NULL;

ALTER TABLE merchants ALTER COLUMN password_hash SET NOT NULL;
CREATE UNIQUE INDEX IF NOT EXISTS uq_merchants_contact_email ON merchants (contact_email);

-- 2. Row Level Security -------------------------------------------------------
-- Tables with a direct tenant_id column: straightforward equality policy.
DO $$
DECLARE
    t TEXT;
BEGIN
    FOREACH t IN ARRAY ARRAY[
        'merchants', 'products', 'buying_pools', 'accounts',
        'journal_transactions', 'master_purchase_orders', 'sub_invoices'
    ]
    LOOP
        EXECUTE format('ALTER TABLE %I ENABLE ROW LEVEL SECURITY', t);
        EXECUTE format('ALTER TABLE %I FORCE ROW LEVEL SECURITY', t);
        EXECUTE format(
            'DROP POLICY IF EXISTS tenant_isolation_policy ON %I', t
        );
        EXECUTE format(
            'CREATE POLICY tenant_isolation_policy ON %I
                USING (tenant_id = current_setting(''app.current_tenant_id'', true)::uuid)
                WITH CHECK (tenant_id = current_setting(''app.current_tenant_id'', true)::uuid)',
            t
        );
    END LOOP;
END $$;

-- Child tables with no tenant_id of their own: scope via their parent.
ALTER TABLE product_tiers ENABLE ROW LEVEL SECURITY;
ALTER TABLE product_tiers FORCE ROW LEVEL SECURITY;
DROP POLICY IF EXISTS tenant_isolation_policy ON product_tiers;
CREATE POLICY tenant_isolation_policy ON product_tiers
    USING (EXISTS (
        SELECT 1 FROM products p
        WHERE p.id = product_tiers.product_id
          AND p.tenant_id = current_setting('app.current_tenant_id', true)::uuid
    ))
    WITH CHECK (EXISTS (
        SELECT 1 FROM products p
        WHERE p.id = product_tiers.product_id
          AND p.tenant_id = current_setting('app.current_tenant_id', true)::uuid
    ));

ALTER TABLE pool_commitments ENABLE ROW LEVEL SECURITY;
ALTER TABLE pool_commitments FORCE ROW LEVEL SECURITY;
DROP POLICY IF EXISTS tenant_isolation_policy ON pool_commitments;
CREATE POLICY tenant_isolation_policy ON pool_commitments
    USING (EXISTS (
        SELECT 1 FROM buying_pools bp
        WHERE bp.id = pool_commitments.pool_id
          AND bp.tenant_id = current_setting('app.current_tenant_id', true)::uuid
    ))
    WITH CHECK (EXISTS (
        SELECT 1 FROM buying_pools bp
        WHERE bp.id = pool_commitments.pool_id
          AND bp.tenant_id = current_setting('app.current_tenant_id', true)::uuid
    ));

ALTER TABLE ledger_entries ENABLE ROW LEVEL SECURITY;
ALTER TABLE ledger_entries FORCE ROW LEVEL SECURITY;
DROP POLICY IF EXISTS tenant_isolation_policy ON ledger_entries;
CREATE POLICY tenant_isolation_policy ON ledger_entries
    USING (EXISTS (
        SELECT 1 FROM journal_transactions jt
        WHERE jt.id = ledger_entries.transaction_id
          AND jt.tenant_id = current_setting('app.current_tenant_id', true)::uuid
    ))
    WITH CHECK (EXISTS (
        SELECT 1 FROM journal_transactions jt
        WHERE jt.id = ledger_entries.transaction_id
          AND jt.tenant_id = current_setting('app.current_tenant_id', true)::uuid
    ));

ALTER TABLE delivery_manifest_items ENABLE ROW LEVEL SECURITY;
ALTER TABLE delivery_manifest_items FORCE ROW LEVEL SECURITY;
DROP POLICY IF EXISTS tenant_isolation_policy ON delivery_manifest_items;
CREATE POLICY tenant_isolation_policy ON delivery_manifest_items
    USING (EXISTS (
        SELECT 1 FROM sub_invoices si
        WHERE si.id = delivery_manifest_items.sub_invoice_id
          AND si.tenant_id = current_setting('app.current_tenant_id', true)::uuid
    ))
    WITH CHECK (EXISTS (
        SELECT 1 FROM sub_invoices si
        WHERE si.id = delivery_manifest_items.sub_invoice_id
          AND si.tenant_id = current_setting('app.current_tenant_id', true)::uuid
    ));

-- `tenants` itself is intentionally NOT restricted here: nothing has a
-- tenant_id column that scopes it, and the app never lists other tenants'
-- rows from user-facing code.
