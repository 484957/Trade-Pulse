import { createContext, useContext, useEffect, useState } from 'react'
import { loginRequest } from '../lib/auth'

const AuthContext = createContext(null)

export function AuthProvider({ children }) {
  const [user, setUser] = useState(null)
  const [ready, setReady] = useState(false)

  useEffect(() => {
    const stored = localStorage.getItem('tpa_user')
    const token = localStorage.getItem('tpa_token')
    if (stored && token) {
      setUser(JSON.parse(stored))
    }
    setReady(true)
  }, [])

  async function login(username, password) {
    const result = await loginRequest(username, password)

    if (!result.roles || !result.roles.includes('ROLE_ADMIN')) {
      throw new Error('This account does not have admin access to the console.')
    }

    const nextUser = {
      merchantId: result.userId,
      tenantId: result.tenantId,
      username: result.username,
      roles: result.roles,
    }
    localStorage.setItem('tpa_token', result.accessToken)
    localStorage.setItem('tpa_user', JSON.stringify(nextUser))
    setUser(nextUser)
    return nextUser
  }

  function logout() {
    localStorage.removeItem('tpa_token')
    localStorage.removeItem('tpa_user')
    setUser(null)
  }

  return <AuthContext.Provider value={{ user, ready, login, logout }}>{children}</AuthContext.Provider>
}

export function useAuth() {
  const ctx = useContext(AuthContext)
  if (!ctx) throw new Error('useAuth must be used inside AuthProvider')
  return ctx
}
