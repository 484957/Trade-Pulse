import { NavLink, useNavigate } from 'react-router-dom'
import { LayoutDashboard, LogOut, Package, ShoppingCart, Users, Wallet } from 'lucide-react'
import { useAuth } from '../context/AuthContext'

export default function Sidebar({ children }) {
  const { user, logout } = useAuth()
  const navigate = useNavigate()

  function handleLogout() {
    logout()
    navigate('/login')
  }

  return (
    <div className="admin-shell">
      <aside className="sidebar">
        <div className="sidebar__brand">
          Trade<span>Pulse</span>
          <span className="sidebar__console-label">ADMIN CONSOLE</span>
        </div>
        <nav className="sidebar__nav">
          <NavLink to="/" end className={({ isActive }) => `sidebar__link${isActive ? ' active' : ''}`}>
            <LayoutDashboard size={16} />
            <span>Dashboard</span>
          </NavLink>
          <NavLink to="/products" className={({ isActive }) => `sidebar__link${isActive ? ' active' : ''}`}>
            <Package size={16} />
            <span>Products</span>
          </NavLink>
          <NavLink to="/pools" className={({ isActive }) => `sidebar__link${isActive ? ' active' : ''}`}>
            <ShoppingCart size={16} />
            <span>Buying pools</span>
          </NavLink>
          <NavLink to="/merchants" className={({ isActive }) => `sidebar__link${isActive ? ' active' : ''}`}>
            <Users size={16} />
            <span>Merchants</span>
          </NavLink>
          <NavLink to="/wallets" className={({ isActive }) => `sidebar__link${isActive ? ' active' : ''}`}>
            <Wallet size={16} />
            <span>Wallets</span>
          </NavLink>
        </nav>
        <div className="sidebar__footer">
          <div>{user?.username}</div>
          <button className="sidebar__logout" onClick={handleLogout}>
            <LogOut size={13} />
            Log out
          </button>
        </div>
      </aside>
      <main className="admin-content">
        <div className="page">{children}</div>
      </main>
    </div>
  )
}
