import { useEffect, useState } from 'react'
import { Link, useParams } from 'react-router-dom'
import { AlertCircle, ArrowLeft, CheckCircle2 } from 'lucide-react'
import Sidebar from '../components/Sidebar'
import Money from '../components/Money'
import { getMerchantBalance, depositFunds } from '../lib/wallet'
import { extractErrorMessage } from '../lib/api'

export default function WalletDetailPage() {
  const { merchantId } = useParams()
  const [overview, setOverview] = useState(null)
  const [loadError, setLoadError] = useState('')

  const [amount, setAmount] = useState('')
  const [depositing, setDepositing] = useState(false)
  const [depositError, setDepositError] = useState('')
  const [depositSuccess, setDepositSuccess] = useState('')

  function load() {
    getMerchantBalance(merchantId)
      .then(setOverview)
      .catch((err) => setLoadError(extractErrorMessage(err, 'Could not load this wallet.')))
  }

  useEffect(load, [merchantId])

  async function handleDeposit(e) {
    e.preventDefault()
    setDepositError('')
    setDepositSuccess('')
    setDepositing(true)
    try {
      await depositFunds(merchantId, Number(amount), 'ADMIN-CREDIT')
      setDepositSuccess(`Deposit of ${amount} recorded on this merchant's behalf.`)
      setAmount('')
      load()
    } catch (err) {
      setDepositError(extractErrorMessage(err, 'Could not process this deposit.'))
    } finally {
      setDepositing(false)
    }
  }

  return (
    <Sidebar>
      <div className="page-head">
        <h1>Merchant wallet</h1>
      </div>

      {loadError && (
        <div className="banner banner--error">
          <AlertCircle size={16} />
          <span>{loadError}</span>
        </div>
      )}

      {!overview && !loadError && (
        <div className="stat-grid">
          {[0, 1, 2].map((i) => (
            <div className="stat-card" key={i}>
              <div className="skeleton skeleton-line" style={{ width: '50%', height: '12px', marginBottom: '0.6rem' }} />
              <div className="skeleton" style={{ height: '26px', width: '75%' }} />
            </div>
          ))}
        </div>
      )}

      {overview && (
        <div className="stat-grid">
          <div className="stat-card">
            <div className="stat-card__label">Available</div>
            <div className="stat-card__value" style={{ color: 'var(--color-positive)' }}>
              <Money value={overview.availableBalance} />
            </div>
          </div>
          <div className="stat-card">
            <div className="stat-card__label">In escrow</div>
            <div className="stat-card__value" style={{ color: 'var(--color-accent-strong)' }}>
              <Money value={overview.escrowHoldBalance} />
            </div>
          </div>
          <div className="stat-card">
            <div className="stat-card__label">Total</div>
            <div className="stat-card__value">
              <Money value={overview.totalBalance} />
            </div>
          </div>
        </div>
      )}

      <div className="panel">
        <h2 style={{ marginBottom: '0.9rem' }}>Credit this wallet</h2>
        <form onSubmit={handleDeposit} style={{ maxWidth: 300 }}>
          {depositError && (
            <div className="banner banner--error">
              <AlertCircle size={16} />
              <span>{depositError}</span>
            </div>
          )}
          {depositSuccess && (
            <div className="banner banner--success">
              <CheckCircle2 size={16} />
              <span>{depositSuccess}</span>
            </div>
          )}
          <div className="field">
            <label htmlFor="amount">Amount</label>
            <input
              id="amount"
              type="number"
              min="1"
              step="0.01"
              value={amount}
              onChange={(e) => setAmount(e.target.value)}
              required
            />
          </div>
          <button type="submit" className="btn btn--primary" disabled={depositing}>
            {depositing ? 'Processing...' : 'Deposit'}
          </button>
        </form>
      </div>

      <Link to="/wallets" className="btn btn--ghost">
        <ArrowLeft size={15} />
        Back to wallets
      </Link>
    </Sidebar>
  )
}
