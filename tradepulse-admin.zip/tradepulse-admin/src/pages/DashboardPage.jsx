import { useEffect, useState } from 'react'
import { Link } from 'react-router-dom'
import { Package, ShoppingCart, Users } from 'lucide-react'
import Sidebar from '../components/Sidebar'
import { listProducts } from '../lib/products'
import { listPools } from '../lib/pools'
import { listMerchants } from '../lib/merchants'

export default function DashboardPage() {
  const [counts, setCounts] = useState(null)

  useEffect(() => {
    Promise.all([listProducts(), listPools(), listMerchants()])
      .then(([products, pools, merchants]) => {
        setCounts({
          products: products.length,
          openPools: pools.filter((p) => p.status === 'OPEN' || p.status === 'THRESHOLD_MET').length,
          totalPools: pools.length,
          merchants: merchants.length,
        })
      })
      .catch(() => setCounts({ products: 0, openPools: 0, totalPools: 0, merchants: 0 }))
  }, [])

  return (
    <Sidebar>
      <div className="page-head">
        <h1>Dashboard</h1>
      </div>

      <div className="stat-grid">
        <div className="stat-card">
          <div className="stat-card__label">
            <Package size={14} />
            Products
          </div>
          <div className="stat-card__value">{counts ? counts.products : <span className="skeleton" style={{ display: 'inline-block', width: '2rem', height: '1.3rem' }} />}</div>
        </div>
        <div className="stat-card">
          <div className="stat-card__label">
            <ShoppingCart size={14} />
            Open pools
          </div>
          <div className="stat-card__value">{counts ? `${counts.openPools} / ${counts.totalPools}` : <span className="skeleton" style={{ display: 'inline-block', width: '2rem', height: '1.3rem' }} />}</div>
        </div>
        <div className="stat-card">
          <div className="stat-card__label">
            <Users size={14} />
            Merchants
          </div>
          <div className="stat-card__value">{counts ? counts.merchants : <span className="skeleton" style={{ display: 'inline-block', width: '2rem', height: '1.3rem' }} />}</div>
        </div>
      </div>

      <div className="panel">
        <h2 style={{ marginBottom: '0.8rem' }}>Quick actions</h2>
        <div style={{ display: 'flex', gap: '0.7rem', flexWrap: 'wrap' }}>
          <Link to="/products" className="btn btn--ghost">
            Manage products
          </Link>
          <Link to="/pools" className="btn btn--ghost">
            Manage buying pools
          </Link>
          <Link to="/merchants" className="btn btn--ghost">
            Verify merchants
          </Link>
        </div>
      </div>
    </Sidebar>
  )
}
