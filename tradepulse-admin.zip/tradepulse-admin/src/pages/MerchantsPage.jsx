import { useEffect, useState } from 'react'
import { AlertCircle, ShieldCheck } from 'lucide-react'
import Sidebar from '../components/Sidebar'
import TableSkeleton from '../components/TableSkeleton'
import { listMerchants, verifyMerchant } from '../lib/merchants'
import { extractErrorMessage } from '../lib/api'

export default function MerchantsPage() {
  const [merchants, setMerchants] = useState(null)
  const [loadError, setLoadError] = useState('')
  const [verifyingId, setVerifyingId] = useState(null)
  const [rowError, setRowError] = useState('')

  function load() {
    listMerchants()
      .then(setMerchants)
      .catch((err) => setLoadError(extractErrorMessage(err, 'Could not load merchants.')))
  }

  useEffect(load, [])

  async function handleVerify(merchantId) {
    setRowError('')
    setVerifyingId(merchantId)
    try {
      await verifyMerchant(merchantId)
      load()
    } catch (err) {
      setRowError(extractErrorMessage(err, 'Could not verify this merchant.'))
    } finally {
      setVerifyingId(null)
    }
  }

  return (
    <Sidebar>
      <div className="page-head">
        <h1>Merchants</h1>
      </div>

      {loadError && (
        <div className="banner banner--error">
          <AlertCircle size={16} />
          <span>{loadError}</span>
        </div>
      )}
      {rowError && (
        <div className="banner banner--error">
          <AlertCircle size={16} />
          <span>{rowError}</span>
        </div>
      )}

      {!merchants && !loadError && <TableSkeleton columns={6} />}

      {merchants && merchants.length === 0 && <div className="empty-state">No merchants registered yet.</div>}

      {merchants && merchants.length > 0 && (
        <div className="data-table-wrap">
          <table className="data-table">
            <thead>
              <tr>
                <th>Business</th>
                <th>Cluster zone</th>
                <th>Contact</th>
                <th>GSTIN</th>
                <th>Status</th>
                <th></th>
              </tr>
            </thead>
            <tbody>
              {merchants.map((m) => (
                <tr key={m.id}>
                  <td>{m.businessName}</td>
                  <td>{m.clusterZone}</td>
                  <td>{m.contactEmail}</td>
                  <td>{m.gstin}</td>
                  <td>
                    <span className={`badge badge--${m.verified ? 'verified' : 'pending'}`}>
                      {m.verified ? 'Verified' : 'Pending'}
                    </span>
                  </td>
                  <td>
                    {!m.verified && (
                      <button
                        className="btn btn--ghost btn--sm"
                        onClick={() => handleVerify(m.id)}
                        disabled={verifyingId === m.id}
                      >
                        <ShieldCheck size={13} />
                        {verifyingId === m.id ? 'Verifying...' : 'Verify'}
                      </button>
                    )}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}
    </Sidebar>
  )
}
