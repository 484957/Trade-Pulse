import { useEffect, useState } from 'react'
import { useNavigate } from 'react-router-dom'
import { AlertCircle, Wallet } from 'lucide-react'
import Sidebar from '../components/Sidebar'
import TableSkeleton from '../components/TableSkeleton'
import { listMerchants } from '../lib/merchants'
import { extractErrorMessage } from '../lib/api'

export default function WalletsPage() {
  const navigate = useNavigate()
  const [merchants, setMerchants] = useState(null)
  const [error, setError] = useState('')

  useEffect(() => {
    listMerchants()
      .then(setMerchants)
      .catch((err) => setError(extractErrorMessage(err, 'Could not load merchants.')))
  }, [])

  return (
    <Sidebar>
      <div className="page-head">
        <h1>Wallets</h1>
      </div>

      {error && (
        <div className="banner banner--error">
          <AlertCircle size={16} />
          <span>{error}</span>
        </div>
      )}

      {!merchants && !error && <TableSkeleton columns={3} />}

      {merchants && merchants.length === 0 && (
        <div className="empty-state">
          <Wallet size={32} style={{ marginBottom: '0.8rem', opacity: 0.5 }} />
          No merchants registered yet.
        </div>
      )}

      {merchants && merchants.length > 0 && (
        <div className="data-table-wrap">
          <table className="data-table">
            <thead>
              <tr>
                <th>Business</th>
                <th>Cluster zone</th>
                <th>Contact</th>
              </tr>
            </thead>
            <tbody>
              {merchants.map((m) => (
                <tr key={m.id} className="clickable" onClick={() => navigate(`/wallets/${m.id}`)}>
                  <td>{m.businessName}</td>
                  <td>{m.clusterZone}</td>
                  <td>{m.contactEmail}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}
    </Sidebar>
  )
}
