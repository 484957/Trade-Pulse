# TradePulse Admin Console

Phase 2: the operations/admin side of TradePulse — managing products and
pricing tiers, creating buying pools, issuing purchase orders, verifying
deliveries, and approving merchants. This is a separate app from
`tradepulse-web` (the merchant-facing app) and runs on its own port so you
can have both open at once.

## Prerequisites

- Node.js 18+
- The TradePulse backend running on `http://localhost:8080`

## Setup

```bash
npm install
npm run dev
```

Opens on `http://localhost:5174` (the merchant app uses 5173, so both can
run simultaneously).

## Logging in

This console now requires a real admin account (backend migration `V5`
added a genuine `ADMIN` role — a regular merchant's login is rejected here
with a clear message, and the underlying admin endpoints return `403` even
if someone calls them directly with a merchant-only token):

- `ops@tradepulse.io` / `AdminPass123!`

## What's here

- **Dashboard** — quick counts (products, open pools, merchants)
- **Products** — create products, add pricing tiers (admin only)
- **Buying pools** — create pools against a product, generate the master PO
  once a pool hits its threshold, and verify deliveries by OTP per
  sub-invoice (admin only)
- **Merchants** — list merchants and mark them as KYC-verified (admin only)

## Known gaps in this phase

- Admin is modeled as a flag on the `merchants` table, not a separate staff
  identity — a pragmatic shortcut, not the ideal long-term shape. Revisit if
  staff ever need permissions merchants should never have at all (e.g. an
  admin who isn't tied to any single tenant).
- No distributor management UI (distributor IDs are free-text/generated placeholders,
  since the backend has no distributor entity or endpoints yet)
- No way to view individual pool commitments (who committed how much) —
  the backend doesn't expose a "list commitments for a pool" endpoint yet
- No wallet/ledger oversight (viewing or adjusting a merchant's balance
  as an admin) — the ledger endpoints that exist are merchant-self-service only
- No nightly batch/reconciliation trigger UI, though the backend has that job
